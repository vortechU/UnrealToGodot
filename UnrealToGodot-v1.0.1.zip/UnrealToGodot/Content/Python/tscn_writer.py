"""
tscn_writer.py  --  Direct Godot 4 text scene (.tscn) writer for the Unreal to Godot toolchain.

This module runs INSIDE Unreal Engine's embedded Python (no Godot available). It consumes a
layout JSON dict (schema v2, see docs/SCHEMA_V2.md) and writes a byte-valid Godot 4 text
scene file that opens in the editor without errors.

Entry point:
    write_tscn(layout_data, output_path, res_paths, options) -> bool

  * layout_data : the full schema-v2 dict (meshes, actors, lights, post_process, height_fog,
                  sky_light, decals, foliage, navigation, landscapes).
  * output_path : absolute filesystem path of the .tscn to write (inside the Godot project).
  * res_paths   : {"models": "res://models/", "textures": "res://textures/",
                   "terrain": "res://terrain/"}.
  * options     : {"scene_name": str, "godot_project_dir": absolute path,
                   "light_energy_scale": float (default 1.0),
                   "lights","decals","foliage","navigation","metadata","landscape": bool}.
                   A missing/False feature flag skips that feature.

The module is importable and unit-testable WITHOUT `unreal` (the import is guarded); it never
raises out of write_tscn (all failures are logged and return False).

MATERIALS: this writer instances the exported .gltf scenes as-is and applies NO material
overrides of its own. Whatever the .gltf carries is what renders. That is why the glTF
export writes baseColorFactor/roughnessFactor/metallicFactor and the base-colour and normal
uris into each material (export_static_meshes_to_gltf.inject_texture_references) rather than
leaving glTF's spec defaults in place -- metallicFactor defaults to 1.0, which would render
every mesh in a .tscn chrome. The packed roughness/metallic/AO map still cannot travel this
way (glTF fixes the channel order and Unreal's packing varies), nor can UV tiling, so a
scene that needs those must go through the Godot-side layout importer, which rebuilds
materials from the layout JSON.

------------------------------------------------------------------------------------------------
Godot 4 .tscn format decisions (verified against godotengine/godot-docs tscn.rst and the
RenderingServer / Transform3D / MultiMesh source semantics):

  * Header: [gd_scene load_steps=N format=3]  where N = 1 + ext_resource_count + sub_resource_count.
    `format=3` marks a Godot 4 scene. `uid` is intentionally omitted -- Godot mints one on first
    save. `load_steps` is advisory (deprecated in 4.6 but still parsed); we emit the classic value.

  * ext_resource ids are "<index>_<token>" strings (e.g. "1_a3f9c"); sub_resource ids are
    "<GodotType>_<token>" (e.g. "BoxShape3D_a3f9c"). Tokens are short base36 counters, guaranteed
    unique within the file. References use ExtResource("id") / SubResource("id").

  * Transform3D(...) serialization is 12 reals: the 3x3 basis in ROW-MAJOR order followed by the
    origin, i.e. [m00,m01,m02, m10,m11,m12, m20,m21,m22, ox,oy,oz]. The basis COLUMN j is the
    rotated+scaled local axis j -> column0 = (m00,m10,m20). We build the basis from the schema's
    quaternion (columns = rotated axes) and scale each column by scale[j] -- the schema's `scale`
    is a LOCAL scale, so it multiplies columns (Godot's Basis.scaled_local), NOT rows (Basis.scaled,
    which applies it in the parent frame). Then compose parent*child as Transform3D multiplication.

  * MultiMesh buffer (transform_format = 1 / TRANSFORM_3D) is a PackedFloat32Array with 12 floats
    per instance laid out as a 3x4 ROW-MAJOR matrix: [m00,m01,m02,ox, m10,m11,m12,oy, m20,m21,m22,oz]
    (origin components live at indices 3, 7, 11). The schema's foliage `godot_transforms` stores
    basis COLUMNS then origin, so we transpose per instance when filling the buffer.

  * MultiMesh mesh binding decision: a Mesh living inside an instanced glTF PackedScene CANNOT be
    referenced from a .tscn (there is no stable sub-resource path to it). We therefore emit each
    MultiMesh with its transform data intact (transform_format, instance_count, buffer) but WITHOUT
    a `mesh` property, and tag the MultiMeshInstance3D node with metadata/source_model (the res://
    glTF path) and metadata/unreal_foliage = true. The Godot addon dock's "bind foliage meshes"
    pass resolves the glTF, extracts its first Mesh, and assigns it to each MultiMesh -- that is the
    orchestrator's job; ours is only to emit valid transform data. Emitting the raw buffer (rather
    than the instance_count=0 + metadata fallback) is safe because the 3x4 layout is well-defined
    and round-trips through Godot's MultiMesh loader.

  * A missing ext_resource file makes the WHOLE scene fail to load, so every ext_resource path is
    verified on disk (case-insensitive) under options["godot_project_dir"] before it is emitted.
    Missing meshes become a Marker3D placeholder ("MISSING_<mesh_key>" + metadata/missing_mesh);
    missing textures simply drop that texture property.
------------------------------------------------------------------------------------------------
"""

import os
import math

try:
    import unreal  # only used for logging when running inside Unreal

    def _log(msg):
        unreal.log("tscn_writer: " + str(msg))

    def _warn(msg):
        unreal.log_warning("tscn_writer: " + str(msg))

    def _err(msg):
        unreal.log_error("tscn_writer: " + str(msg))
except Exception:  # pragma: no cover - exercised only outside Unreal
    def _log(msg):
        print("tscn_writer: " + str(msg))

    def _warn(msg):
        print("tscn_writer [WARN]: " + str(msg))

    def _err(msg):
        print("tscn_writer [ERROR]: " + str(msg))


# ----------------------------------------------------------------------------------------------
# Small local math / formatting helpers (deliberately NOT imported from ue2g_common, which does
# `import unreal` at module top and is therefore unusable without Unreal).
# ----------------------------------------------------------------------------------------------

def _num(value, default=0.0):
    """Coerce a possibly-None/str JSON scalar to a finite float."""
    try:
        f = float(value)
        if math.isfinite(f):
            return f
        return default
    except (TypeError, ValueError):
        return default


def _clamp(value, low, high):
    """Clamps to [low, high]; the .tscn twin of GDScript's clampf()."""
    return low if value < low else (high if value > high else value)


# ---------------------------------------------------------------------------
# Environment and light constants. These MIRROR
# addons/unreal_importer/import_environment.gd -- the .tscn writer and the
# runtime addon build the same lights and WorldEnvironment from the same
# layout, and they are only consistent because these agree. Change one, change
# the other; tests/test_tscn_writer.py checks them against each other.
# ---------------------------------------------------------------------------
_TONEMAP_ACES = 3               # Environment.TONE_MAPPER_ACES
_UE_DEFAULT_EXPOSURE_BIAS = 1.0
_MIDDLE_GREY = 0.18
_ISO_REFERENCE = 100.0
_EXPOSURE_SPEED_SCALE = 0.5 / 3.0

# Mirrors import_environment.gd, which explains these.
FOG_DENSITY_SCALE = 0.0480453
FOG_DEPTH_RANGE = 1.2
SKY_SHADER = """shader_type sky;

uniform vec3 top;
uniform vec3 horizon;
uniform vec3 ground;
uniform float falloff;
uniform vec3 light_scale;

void sky() {
	float elevation = asin(clamp(EYEDIR.y, 0.0, 1.0)) / (0.5 * PI);
	COLOR = mix(top, horizon, pow(1.0 - elevation, falloff));
	// Lighting only: Unreal scales the sky light and replaces its lower half, not the sky you see.
	if (AT_CUBEMAP_PASS) {
		COLOR = (EYEDIR.y >= 0.0 ? COLOR : ground) * light_scale;
	}
}
"""

# UE's own default AttenuationRadius (1000 cm), used when the field is missing.
DEFAULT_ATTENUATION_M = 10.0
# Godot rejects spot_angle >= 90; UE's OuterConeAngle clamps at 89.9.
MAX_SPOT_ANGLE_DEG = 89.9
# Godot's per-class light_specular defaults. UE's SpecularScale is a multiplier
# against them, so a default UE light keeps Godot's stock look.
GODOT_DIRECTIONAL_SPECULAR = 1.0
GODOT_LOCAL_SPECULAR = 0.5

# GeometryInstance3D enums, used by the foliage MultiMeshInstance3D nodes.
_SHADOW_CASTING_OFF = 0            # SHADOW_CASTING_SETTING_OFF
_VISIBILITY_RANGE_FADE_SELF = 1    # VISIBILITY_RANGE_FADE_SELF


def _spot_softness(inner_deg, outer_deg):
    """Twin of import_environment.gd::_spot_softness."""
    outer = math.cos(math.radians(_clamp(outer_deg, 0.5, MAX_SPOT_ANGLE_DEG)))
    inner = max(math.cos(math.radians(max(inner_deg, 0.0))), outer)
    rim = (1.0 - (outer + math.sqrt(0.5) * (inner - outer))) / (1.0 - outer)
    return _clamp(math.log(rim) / math.log(0.5), 0.05, 8.0)


def _grade_scale(settings):
    """Twin of import_environment.gd::_grade_scale."""
    gain = settings.get("gain")
    gamma = settings.get("gamma")
    scale = 1.0
    if isinstance(gain, (list, tuple)):
        scale *= max(_avg3(gain) * (_num(gain[3], 1.0) if len(gain) > 3 else 1.0), 0.0)
    if isinstance(gamma, (list, tuple)):
        power = _avg3(gamma) * (_num(gamma[3], 1.0) if len(gamma) > 3 else 1.0)
        scale *= _MIDDLE_GREY ** (1.0 / max(power, 0.01) - 1.0)
    return scale


def _exposure_for_settings(settings):
    """Maps a volume's exposure settings to (tonemap_exposure | None, camera-attr lines).

    The Python twin of import_environment.gd::_apply_exposure -- see that function
    for why locked / ranged / bias-only are three different shapes. The second
    element is non-empty only for a real adaptation range, since Godot models auto
    exposure on CameraAttributes rather than on Environment.
    """
    has_bias = settings.get("exposure_bias") is not None
    bias = _num(settings.get("exposure_bias"), _UE_DEFAULT_EXPOSURE_BIAS)
    grade = _grade_scale(settings)
    bias_scale = 2.0 ** bias * grade

    min_raw = settings.get("exposure_min_brightness")
    max_raw = settings.get("exposure_max_brightness")
    if min_raw is None or max_raw is None:
        if has_bias:
            return bias_scale, []
        return (grade if grade != 1.0 else None), []

    min_lum = max(_num(min_raw, 1.0), 0.0001)
    max_lum = max(_num(max_raw, 1.0), 0.0001)

    if abs(min_lum - max_lum) <= 1e-6 * max(1.0, abs(min_lum), abs(max_lum)):
        # Locked exposure ("manual"): no auto exposure, just the fixed multiplier.
        return _clamp(_MIDDLE_GREY / min_lum * bias_scale, 0.0, 64.0), []

    # Sensitivity is inverse to target luminance, so min/max swap sides.
    lines = [
        "auto_exposure_enabled = true",
        "auto_exposure_min_sensitivity = " + _f(_clamp(_ISO_REFERENCE / max_lum, 0.0, 64000.0)),
        "auto_exposure_max_sensitivity = " + _f(_clamp(_ISO_REFERENCE / min_lum, 0.0, 64000.0)),
    ]
    if settings.get("exposure_speed_up") is not None:
        lines.append("auto_exposure_speed = "
                     + _f(max(_num(settings.get("exposure_speed_up"), 3.0)
                              * _EXPOSURE_SPEED_SCALE, 0.01)))
    return bias_scale, lines


def _f(value, default=0.0):
    """Format a float compactly but precisely (shortest round-trip repr). Godot accepts
    plain decimals and scientific notation."""
    f = _num(value, default)
    # repr() gives the shortest string that round-trips; ensure a decimal point / exponent
    # so Godot parses it as a float rather than an int where that matters.
    s = repr(f)
    return s


def _quat_to_matrix(quat):
    """Unit quaternion [x, y, z, w] -> 3x3 rotation matrix (row-major, columns = rotated axes).
    Matches Godot's Basis(Quaternion) and ue2g_common's convention."""
    x = _num(quat[0]) if len(quat) > 0 else 0.0
    y = _num(quat[1]) if len(quat) > 1 else 0.0
    z = _num(quat[2]) if len(quat) > 2 else 0.0
    w = _num(quat[3]) if len(quat) > 3 else 1.0
    n = (x * x + y * y + z * z + w * w) ** 0.5
    if n > 1e-12:
        x, y, z, w = x / n, y / n, z / n, w / n
    else:
        x, y, z, w = 0.0, 0.0, 0.0, 1.0
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z
    return [
        [1.0 - 2.0 * (yy + zz), 2.0 * (xy - wz), 2.0 * (xz + wy)],
        [2.0 * (xy + wz), 1.0 - 2.0 * (xx + zz), 2.0 * (yz - wx)],
        [2.0 * (xz - wy), 2.0 * (yz + wx), 1.0 - 2.0 * (xx + yy)],
    ]


def _transform_dict_to_mat(t):
    """Schema transform dict -> (rows3x3, origin3). Column j of the basis is scaled by scale[j]:
    the schema's `scale` is LOCAL to the node, so it scales columns (Godot Basis.scaled_local),
    not rows (Basis.scaled, which would apply the scale in the parent frame)."""
    if not isinstance(t, dict):
        return ([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]], [0.0, 0.0, 0.0])
    trans = t.get("translation") or [0.0, 0.0, 0.0]
    quat = t.get("rotation_quat") or [0.0, 0.0, 0.0, 1.0]
    scale = t.get("scale") or [1.0, 1.0, 1.0]
    sx = _num(scale[0], 1.0) if len(scale) > 0 else 1.0
    sy = _num(scale[1], 1.0) if len(scale) > 1 else 1.0
    sz = _num(scale[2], 1.0) if len(scale) > 2 else 1.0
    r = _quat_to_matrix(quat)
    rows = [
        [r[0][0] * sx, r[0][1] * sy, r[0][2] * sz],
        [r[1][0] * sx, r[1][1] * sy, r[1][2] * sz],
        [r[2][0] * sx, r[2][1] * sy, r[2][2] * sz],
    ]
    origin = [
        _num(trans[0]) if len(trans) > 0 else 0.0,
        _num(trans[1]) if len(trans) > 1 else 0.0,
        _num(trans[2]) if len(trans) > 2 else 0.0,
    ]
    return (rows, origin)


def _mat_compose(parent, child):
    """Godot Transform3D multiplication: result = parent * child (parent applied last)."""
    pr, po = parent
    cr, co = child
    rows = [[sum(pr[i][k] * cr[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    origin = [sum(pr[i][k] * co[k] for k in range(3)) + po[i] for i in range(3)]
    return (rows, origin)


_IDENTITY_MAT = ([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]], [0.0, 0.0, 0.0])

# Unreal's glTF exporter bakes mesh geometry in the (X, Z, Y) axis order, but the
# layout places actors/components with the (Y, Z, -X) convention. The two right-
# handed maps differ by a +90 deg yaw about up, so a mesh dropped at its layout
# transform yaws about its own pivot -- invisible on centre-pivoted props, but it
# scatters every off-centre modular piece (the "scattered building" bug). This is
# a pure rotation (columns = rotated axes): local X -> -Z, local Y -> Y, local Z -> X.
# Post-multiplying a placement basis by it re-seats the mesh (and the collision that
# rides under it) where it belongs. Mirrors Common.gltf_mesh_placement in
# import_common.gd; proof in tests/test_math.py section 9.
_MESH_AXIS_FIX = ([[0.0, 0.0, 1.0], [0.0, 1.0, 0.0], [-1.0, 0.0, 0.0]], [0.0, 0.0, 0.0])


def _apply_mesh_axis_fix(mat):
    """Post-multiply a layout placement by the glTF axis correction so a glTF mesh
    sitting at identity beneath it lands aligned. Origin is preserved."""
    return _mat_compose(mat, _MESH_AXIS_FIX)


def _mat_affine_inverse(mat):
    """Godot Transform3D.affine_inverse(): inverts a basis that may carry scale/shear.

    Falls back to identity on a singular basis (an actor scaled to zero on some
    axis), which keeps the export running instead of raising mid-write.
    """
    rows, origin = mat
    a, b, c = rows[0]
    d, e, f = rows[1]
    g, h, i = rows[2]
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-12:
        _warn("actor basis is singular (zero scale?); using identity inverse")
        return _IDENTITY_MAT
    inv_det = 1.0 / det
    inv = [
        [(e * i - f * h) * inv_det, (c * h - b * i) * inv_det, (b * f - c * e) * inv_det],
        [(f * g - d * i) * inv_det, (a * i - c * g) * inv_det, (c * d - a * f) * inv_det],
        [(d * h - e * g) * inv_det, (b * g - a * h) * inv_det, (a * e - b * d) * inv_det],
    ]
    inv_origin = [-sum(inv[r][k] * origin[k] for k in range(3)) for r in range(3)]
    return (inv, inv_origin)


# ----------------------------------------------------------------------------------------------
# Physics-body scale handling. The exact twin of import_common.gd's block of the same name --
# read that one for why this exists. In short: Jolt cannot apply a non-uniform (or mirrored)
# scale to a sphere, a capsule, or any rotated shape. It does not fail loudly; it replaces the
# scale with the arithmetic MEAN of the three axes and logs an error per body on every scene
# load, leaving the collider a few percent off the mesh it was exported to hug. So a StaticBody3D
# emitted here carries rotation and translation only, and the scale is baked into the shapes and
# the mesh instance underneath it.
#
# The two implementations must agree: a .tscn export and an addon import of the same layout are
# meant to be interchangeable. tests/test_tscn_writer.py pins them against each other.
# ----------------------------------------------------------------------------------------------

SCALE_UNIFORM_EPSILON = 1e-4
_UNIT_SCALE = (1.0, 1.0, 1.0)

# Node every mesh actor is emitted under; mirrors STATIC_MESH_CONTAINER in
# import_unreal_layout.gd. The sibling containers mirror the addon's feature modules.
STATIC_MESH_CONTAINER = "UnrealStaticMeshes"
LIGHT_CONTAINER = "UnrealLights"
DECAL_CONTAINER = "UnrealDecals"
REFLECTION_PROBE_CONTAINER = "UnrealReflectionProbes"
CAMERA_CONTAINER = "UnrealCameras"
AUDIO_CONTAINER = "UnrealAudio"

# Minimum decal projection depth (m), mirroring import_environment.gd's
# DEFAULT_DECAL_MIN_DEPTH_M -- the two importer paths must build the same Decal.
# Unreal packs author boxes as thin as 16 mm; Godot clips to the box just as
# Unreal does, so on a wall with any relief such a box shreds the decal into
# slivers. Measured on a real GPU: a 16 mm box lands 2103 px of an Exit sign
# where a 100 mm box lands 4503. Set the decal_min_depth_m option to 0 to keep
# Unreal's depths untouched.
DEFAULT_DECAL_MIN_DEPTH_M = 0.10


def _decal_size_with_min_depth(size, transform, min_depth):
    """
    size_m with its projection depth (index 1) floored at min_depth.

    The floor is on the EFFECTIVE depth -- size[1] times the node's Y scale --
    because layouts from before v1.0 keep Unreal's scale in the transform, where
    size[1] is routinely 0.02 against a scale of several hundred.
    """
    out = [max(abs(_num(size[i], 1.0)) if len(size) > i else 1.0, 0.01) for i in range(3)]
    try:
        min_depth = float(min_depth)
    except (TypeError, ValueError):
        return out
    if min_depth <= 0.0:
        return out
    scale = (transform or {}).get("scale") if isinstance(transform, dict) else None
    y_scale = abs(_num(scale[1], 1.0)) if isinstance(scale, (list, tuple)) and len(scale) > 1 else 1.0
    if y_scale <= 1e-4:
        return out
    out[1] = max(out[1], min_depth / y_scale)
    return out
FOLIAGE_CONTAINER = "UnrealFoliage"
NAVIGATION_CONTAINER = "UnrealNavigation"

# Navigation bake source, mirroring import_common.gd's NAV_SOURCE_GROUP.
NAV_SOURCE_GROUP = "unreal_nav_source"
_PARSED_GEOMETRY_BOTH = 2                  # NavigationMesh.PARSED_GEOMETRY_BOTH
_SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN = 1  # NavigationMesh.SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN

# Metadata the writer itself puts on actor nodes. A Blueprint variable of the same
# name would emit the key twice, which Godot rejects.
_RESERVED_META_KEYS = frozenset((
    "unreal_actor_id", "unreal_class", "unreal_tags", "missing_mesh", "unreal_mesh_key",
    "unreal_physics_file", "unreal_lod_files", "unreal_spline_mesh"))


def _mat_column(rows, j):
    return (rows[0][j], rows[1][j], rows[2][j])


def _vec_length(v):
    return math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])


def _rows_determinant(r):
    return (r[0][0] * (r[1][1] * r[2][2] - r[1][2] * r[2][1])
            - r[0][1] * (r[1][0] * r[2][2] - r[1][2] * r[2][0])
            + r[0][2] * (r[1][0] * r[2][1] - r[1][1] * r[2][0]))


def _basis_local_scale(rows):
    """The LOCAL scale of a basis: the length of each COLUMN, with a mirrored basis's
    handedness folded into X (so rotation * diag(scale) reproduces the basis)."""
    s = [_vec_length(_mat_column(rows, j)) for j in range(3)]
    if _rows_determinant(rows) < 0.0:
        s[0] = -s[0]
    return s


def _scale_is_body_safe(scale):
    """True when a physics body may carry this scale directly: Jolt accepts a uniform,
    non-mirrored scale on every shape type and nothing else."""
    if scale[0] < 0.0 or scale[1] < 0.0 or scale[2] < 0.0:
        return False
    hi = max(scale)
    if hi <= 0.0:
        return True
    return (hi - min(scale)) / hi <= SCALE_UNIFORM_EPSILON


def _physics_body_scale(mat):
    """The part of a placement's scale that must be baked into the shapes rather than
    left on the StaticBody3D. (1, 1, 1) means "nothing to bake"."""
    s = _basis_local_scale(mat[0])
    if _scale_is_body_safe(s):
        return list(_UNIT_SCALE)
    return s


def _physics_body_mat(mat):
    """A placement with the Jolt-unsafe scale stripped off. A uniform scale is returned
    untouched, so an ordinary prop keeps exactly the transform it had."""
    scale = _physics_body_scale(mat)
    if tuple(scale) == _UNIT_SCALE:
        return mat
    rows, origin = mat
    axes = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
    cols = []
    for j in range(3):
        col = _mat_column(rows, j)
        cols.append([c / scale[j] for c in col] if abs(scale[j]) > 1e-9 else axes[j])
    return ([[cols[j][i] for j in range(3)] for i in range(3)], origin)


def _scale_diag(scale):
    return ([[scale[0], 0.0, 0.0], [0.0, scale[1], 0.0], [0.0, 0.0, scale[2]]], [0.0, 0.0, 0.0])


def _scaled_shape_mat(local_mat, scale):
    """A box/sphere/capsule's local transform once `scale` has come off the body: the
    OFFSET moves with the scale and the rotation is mirrored by its signs, but never
    sheared. Twin of import_common.gd's scaled_shape_transform. Convex hulls carry the
    mirror in their points instead and must keep their own basis."""
    if tuple(scale) == _UNIT_SCALE:
        return local_mat
    rows, origin = local_mat
    sign = [-1.0 if s < 0.0 else 1.0 for s in scale]
    # A reflected basis is not a rotation; negating one column of these symmetric
    # shapes gives the same shape in a right-handed frame.
    flip_x = sign[0] * sign[1] * sign[2]
    out = [[sign[i] * rows[i][0] * flip_x, sign[i] * rows[i][1], sign[i] * rows[i][2]]
           for i in range(3)]
    return (out, [origin[i] * scale[i] for i in range(3)])


def _scaled_axis_factors(local_rows, scale):
    """How much each of a shape's OWN axes stretches under a body scale applied in the
    parent frame. Exact when the shape's rotation is axis-aligned with the scale (what
    Unreal's simple collision almost always is); otherwise the closest a primitive can
    get, since the true result is a shear no primitive expresses. Convex hulls skip
    this and take the shear exactly, per vertex."""
    if tuple(scale) == _UNIT_SCALE:
        return list(_UNIT_SCALE)
    out = []
    for j in range(3):
        col = _mat_column(local_rows, j)
        before = _vec_length(col)
        if before <= 1e-9:
            out.append(1.0)
        else:
            out.append(_vec_length([col[i] * scale[i] for i in range(3)]) / before)
    return out


def _uniform_factor(scale):
    """The single factor a shape that cannot scale non-uniformly (a sphere) settles for."""
    return (abs(scale[0]) + abs(scale[1]) + abs(scale[2])) / 3.0


def _component_world_mat(comp, actor_mat):
    """A component's absolute placement, taken from the exporter rather than composed.

    Unreal's get_relative_transform() is measured against a component's IMMEDIATE
    parent component, and an actor's ROOT component has none -- its relative
    transform is already the world transform. Composing actor * relative therefore
    doubles the placement of every plain StaticMeshActor and drops intermediate
    transforms for deeply nested Blueprint components. Mirrors
    component_world_transform() in import_unreal_layout.gd.
    """
    if isinstance(comp, dict) and isinstance(comp.get("godot_world_transform"), dict):
        return _transform_dict_to_mat(comp["godot_world_transform"])
    return actor_mat


def _mat_to_transform3d(mat):
    """(rows3x3, origin3) -> 'Transform3D(m00,m01,m02, m10,m11,m12, m20,m21,m22, ox,oy,oz)'."""
    rows, origin = mat
    vals = [
        rows[0][0], rows[0][1], rows[0][2],
        rows[1][0], rows[1][1], rows[1][2],
        rows[2][0], rows[2][1], rows[2][2],
        origin[0], origin[1], origin[2],
    ]
    return "Transform3D(" + ", ".join(_f(v) for v in vals) + ")"


def _escape_string(s):
    """Escape a Python string for a Godot quoted string literal."""
    s = "" if s is None else str(s)
    s = s.replace("\\", "\\\\").replace('"', '\\"')
    s = s.replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t")
    return s


_NODE_NAME_BAD = set('.:@/%"\'')


def _sanitize_node_name(name):
    """Godot node names must be non-empty and free of . : @ / % (and we also drop quotes/spaces
    edges). Invalid chars become underscores."""
    out = []
    for ch in str(name):
        if ch in _NODE_NAME_BAD or ord(ch) < 32:
            out.append("_")
        else:
            out.append(ch)
    result = "".join(out).strip().strip("_")
    return result if result else "Node"


def _sanitize_meta_key(key):
    """Godot .tscn metadata keys must be valid unquoted identifiers ([A-Za-z0-9_],
    not starting with a digit), matching import_gameplay.gd::_sanitize_meta_key."""
    out = []
    for ch in str(key or ""):
        if ("a" <= ch <= "z") or ("A" <= ch <= "Z") or ("0" <= ch <= "9") or ch == "_":
            out.append(ch)
        else:
            out.append("_")
    result = "".join(out)
    if not result:
        return "_"
    if "0" <= result[0] <= "9":
        result = "_" + result
    return result


def _linear_to_srgb(v):
    return v * 12.92 if v < 0.0031308 else 1.055 * v ** (1.0 / 2.4) - 0.055


def _color_literal(rgb, alpha=1.0):
    """Linear [r,g,b(,a)] -> 'Color(r, g, b, a)', in the sRGB Godot's properties use."""
    if not isinstance(rgb, (list, tuple)):
        rgb = [1.0, 1.0, 1.0]
    return _srgb_literal([_linear_to_srgb(_num(v, 1.0)) for v in rgb[:3]] + list(rgb[3:4]), alpha)


def _srgb_literal(rgb, alpha=1.0):
    """[r,g,b(,a)] -> 'Color(r, g, b, a)'."""
    if not isinstance(rgb, (list, tuple)):
        rgb = [1.0, 1.0, 1.0]
    r = _num(rgb[0], 1.0) if len(rgb) > 0 else 1.0
    g = _num(rgb[1], 1.0) if len(rgb) > 1 else 1.0
    b = _num(rgb[2], 1.0) if len(rgb) > 2 else 1.0
    a = _num(rgb[3], alpha) if len(rgb) > 3 else alpha
    return "Color(" + ", ".join(_f(v) for v in (r, g, b, a)) + ")"


def _vec3_literal(vec):
    x = _num(vec[0]) if len(vec) > 0 else 0.0
    y = _num(vec[1]) if len(vec) > 1 else 0.0
    z = _num(vec[2]) if len(vec) > 2 else 0.0
    return "Vector3(" + ", ".join(_f(v) for v in (x, y, z)) + ")"


def _vec2_literal(vec):
    x = _num(vec[0]) if len(vec) > 0 else 0.0
    y = _num(vec[1]) if len(vec) > 1 else 0.0
    return "Vector2(" + ", ".join(_f(v) for v in (x, y)) + ")"


def _kelvin_to_rgb(kelvin):
    """Tanner Helland blackbody approximation -> sRGB multiplier (0..1)."""
    t = max(1000.0, min(15000.0, _num(kelvin, 6500.0))) / 100.0

    def clamp(v):
        return max(0.0, min(255.0, v))

    if t <= 66.0:
        r = 255.0
        g = clamp(99.4708025861 * math.log(t) - 161.1195681661) if t > 0 else 0.0
    else:
        r = clamp(329.698727446 * ((t - 60.0) ** -0.1332047592))
        g = clamp(288.1221695283 * ((t - 60.0) ** -0.0755148492))
    if t >= 66.0:
        b = 255.0
    elif t <= 19.0:
        b = 0.0
    else:
        b = clamp(138.5177312231 * math.log(t - 10.0) - 305.0447927307)
    return [r / 255.0, g / 255.0, b / 255.0]


# ----------------------------------------------------------------------------------------------
# The writer
# ----------------------------------------------------------------------------------------------

_MODEL_EXTS = (".gltf", ".glb")
_TEXTURE_EXTS = (".png", ".tga", ".jpg", ".jpeg", ".dds", ".exr", ".webp")


def _cull_chunks(vals, count, cull_end):
    """Splits a distance-culled foliage group into grid cells of instance indices.

    Unreal culls each instance; Godot culls a whole MultiMesh by the distance to its
    centre, so one MultiMesh across a level would vanish under the camera's feet.
    Mirrors import_foliage.gd::_cull_chunks."""
    if count <= 0 or cull_end <= 0.0:
        return [list(range(count))]
    xs = [vals[i * 12 + 9] for i in range(count)]
    zs = [vals[i * 12 + 11] for i in range(count)]
    x0, z0 = min(xs), min(zs)
    cell = max(cull_end * 0.5, max(max(xs) - x0, max(zs) - z0) / 32.0)
    cells = {}
    for i in range(count):
        cells.setdefault((int((xs[i] - x0) / cell), int((zs[i] - z0) / cell)), []).append(i)
    return list(cells.values())


class _TscnWriter(object):
    def __init__(self, layout_data, res_paths, options):
        self.layout = layout_data or {}
        self.res_paths = res_paths or {}
        self.options = options or {}
        self.project_dir = self.options.get("godot_project_dir") or ""
        self.light_energy_scale = _num(self.options.get("light_energy_scale", 1.0), 1.0)

        self.models_res = self._norm_res_dir(self.res_paths.get("models", "res://models/"))
        self.textures_res = self._norm_res_dir(self.res_paths.get("textures", "res://textures/"))
        self.terrain_res = self._norm_res_dir(self.res_paths.get("terrain", "res://terrain/"))
        self.audio_res = self._norm_res_dir(self.res_paths.get("audio", "res://audio/"))

        self._token_counter = 0
        self._ext_index = 0
        self._ext_by_path = {}          # res_path -> ext id
        self._ext_resources = []        # list of (id, type, res_path)
        self._sub_resources = []        # list of (id, type, [body_lines]) in dependency order
        self._nodes = []                # list of node text blocks (each a list of lines)
        self._child_names = {}          # parent_path -> set(used names)

        # cache of on-disk directory listings for case-insensitive existence checks
        self._dir_cache = {}

    # --- id / token generation ---------------------------------------------------------------
    def _token(self):
        self._token_counter += 1
        n = self._token_counter
        # base36 encode, keep it short and alphanumeric
        digits = "0123456789abcdefghijklmnopqrstuvwxyz"
        s = ""
        while True:
            s = digits[n % 36] + s
            n //= 36
            if n == 0:
                break
        return s.rjust(5, "0")

    def _new_ext_id(self):
        self._ext_index += 1
        return "%d_%s" % (self._ext_index, self._token())

    def _new_sub_id(self, godot_type):
        return "%s_%s" % (godot_type, self._token())

    # --- res:// <-> filesystem ---------------------------------------------------------------
    @staticmethod
    def _norm_res_dir(d):
        d = str(d or "").replace("\\", "/")
        if not d:
            return "res://"
        if not d.endswith("/"):
            d += "/"
        return d

    def _res_to_fs(self, res_path):
        """Map a res:// path to an absolute filesystem path under the Godot project dir."""
        rp = str(res_path).replace("\\", "/")
        if rp.startswith("res://"):
            rp = rp[len("res://"):]
        rp = rp.lstrip("/")
        if not self.project_dir:
            return rp
        return os.path.join(self.project_dir, *[p for p in rp.split("/") if p])

    def _dir_listing_lower(self, folder):
        key = os.path.normcase(os.path.abspath(folder)) if folder else ""
        if key in self._dir_cache:
            return self._dir_cache[key]
        listing = {}
        try:
            if folder and os.path.isdir(folder):
                for name in os.listdir(folder):
                    listing[name.lower()] = name
        except Exception:
            listing = {}
        self._dir_cache[key] = listing
        return listing

    def _resolve_existing_res(self, res_dir, base_name, exts):
        """Return a res:// path for the first existing file <res_dir><base_name><ext>, matching
        case-insensitively on disk. Returns None if nothing exists (or project dir unknown)."""
        res_dir = self._norm_res_dir(res_dir)
        fs_dir = self._res_to_fs(res_dir)
        # If we cannot verify (no project dir), be conservative and treat as missing.
        if not self.project_dir or not os.path.isdir(fs_dir):
            return None
        # 1. Exact case
        for ext in exts:
            candidate = base_name + ext
            if os.path.exists(os.path.join(fs_dir, candidate)):
                return res_dir + candidate
        # 2. Case-insensitive scan
        listing = self._dir_listing_lower(fs_dir)
        for ext in exts:
            want = (base_name + ext).lower()
            if want in listing:
                return res_dir + listing[want]
        return None

    # --- resource registration ---------------------------------------------------------------
    def _register_ext(self, godot_type, res_path):
        existing = self._ext_by_path.get(res_path)
        if existing:
            return existing
        eid = self._new_ext_id()
        self._ext_by_path[res_path] = eid
        self._ext_resources.append((eid, godot_type, res_path))
        return eid

    def _register_sub(self, godot_type, body_lines):
        sid = self._new_sub_id(godot_type)
        self._sub_resources.append((sid, godot_type, list(body_lines)))
        return sid

    # --- node emission -----------------------------------------------------------------------
    def _unique_child_name(self, parent_path, name):
        name = _sanitize_node_name(name)
        used = self._child_names.setdefault(parent_path, set())
        if name not in used:
            used.add(name)
            return name
        i = 2
        while ("%s_%d" % (name, i)) in used:
            i += 1
        final = "%s_%d" % (name, i)
        used.add(final)
        return final

    @staticmethod
    def _child_path(parent_path, name):
        if parent_path is None:
            return "."
        if parent_path == ".":
            return name
        return parent_path + "/" + name

    def _add_node(self, name, godot_type=None, parent_path=".", instance_id=None,
                  props=None, metadata=None, groups=None):
        """Append a node block. Returns the path used by this node's children as their `parent`.
        `parent_path=None` marks the scene root (no parent attr)."""
        uname = self._unique_child_name(parent_path, name)
        header = '[node name="%s"' % _escape_string(uname)
        if godot_type is not None:
            header += ' type="%s"' % godot_type
        if parent_path is not None:
            header += ' parent="%s"' % _escape_string(parent_path)
        if groups:
            header += " groups=[%s]" % ", ".join('"%s"' % _escape_string(g) for g in groups)
        if instance_id is not None:
            header += ' instance=ExtResource("%s")' % instance_id
        header += "]"

        lines = [header]
        for line in (props or []):
            lines.append(line)
        for line in (metadata or []):
            lines.append(line)
        self._nodes.append(lines)
        return self._child_path(parent_path, uname)

    # --- metadata helpers --------------------------------------------------------------------
    @staticmethod
    def _meta_value_literal(value):
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            return _f(value)
        return '"%s"' % _escape_string(value)

    def _actor_metadata_lines(self, actor, extra_tags=None):
        lines = []
        # The id is what an incremental re-import matches on, so unlike the rest it
        # does not depend on the "metadata" option.
        aid = actor.get("actor_id")
        if aid:
            lines.append('metadata/unreal_actor_id = "%s"' % _escape_string(aid))
        if not self.options.get("metadata"):
            return lines
        cls = actor.get("class")
        if cls:
            lines.append('metadata/unreal_class = "%s"' % _escape_string(cls))
        merged_tags = []
        for source in (actor.get("tags"), extra_tags):
            if isinstance(source, (list, tuple)):
                for t in source:
                    s = str(t)
                    if s and s not in merged_tags:
                        merged_tags.append(s)
        if merged_tags:
            lines.append("metadata/unreal_tags = [%s]"
                         % ", ".join('"%s"' % _escape_string(t) for t in merged_tags))
        props = actor.get("properties")
        if isinstance(props, dict):
            seen_keys = set(_RESERVED_META_KEYS)
            for k, v in props.items():
                if v is None:
                    continue
                key = _sanitize_meta_key(k)
                if key in seen_keys:
                    continue
                seen_keys.add(key)
                lines.append("metadata/%s = %s" % (key, self._meta_value_literal(v)))
        return lines

    @staticmethod
    def _component_metadata_lines(comp):
        lines = []
        tags = comp.get("tags")
        if isinstance(tags, (list, tuple)) and tags:
            lines.append("metadata/unreal_tags = [%s]"
                         % ", ".join('"%s"' % _escape_string(t) for t in tags))
        return lines

    def _mesh_extra_metadata_lines(self, mesh_key, meshes_lib, mesh_name=None):
        """Emits LOD / skeletal-physics handover metadata onto instanced mesh
        nodes so dock utilities can bind them on directly-generated .tscn scenes."""
        lines = []
        entry = (meshes_lib or {}).get(mesh_key)
        if not isinstance(entry, dict):
            return lines
        lods = entry.get("lods")
        if isinstance(lods, list) and len(lods) > 1:
            lod_paths = []
            for item in lods:
                lod = int(_num(item.get("lod_index"), 0)) if isinstance(item, dict) else 0
                if lod > 0:
                    rp = self._mesh_res_path(item.get("export_name") or "%s_LOD%d" % (mesh_key, lod),
                                             "%s_LOD%d" % (mesh_name, lod) if mesh_name else None)
                    if rp:
                        lod_paths.append(rp)
            if lod_paths:
                lines.append("metadata/unreal_lod_files = PackedStringArray(%s)"
                             % ", ".join('"%s"' % _escape_string(p) for p in lod_paths))
        phys = entry.get("physics_file")
        if phys:
            lines.append('metadata/unreal_mesh_key = "%s"' % _escape_string(mesh_key))
            lines.append('metadata/unreal_physics_file = "%s"' % _escape_string(self.models_res + os.path.basename(str(phys))))
        return lines

    # --- collision -> shape sub_resources ----------------------------------------------------
    def _emit_collision(self, parent_path, collision, scale=_UNIT_SCALE):
        """Emit CollisionShape3D child nodes (+ shape sub_resources) mirroring the GDScript
        importer's setup_physics_body math. `parent_path` is the StaticBody3D.

        `scale` is whatever the body could not carry (see _physics_body_scale); it is
        (1, 1, 1) for a uniformly scaled prop, and then every shape below is built exactly
        as it was before this existed."""
        if not isinstance(collision, dict):
            return
        scale = list(scale)
        for box in collision.get("boxes") or []:
            size = box.get("size") if isinstance(box, dict) else None
            if not isinstance(size, (list, tuple)) or len(size) < 3:
                continue
            local = _transform_dict_to_mat(box.get("godot_local_transform"))
            factors = _scaled_axis_factors(local[0], scale)
            # Full extents cm -> m with glTF [x, z, y] axis remap (matches importer BoxShape3D.size)
            gx = abs(_num(size[0])) * 0.01 * factors[0]
            gy = abs(_num(size[2])) * 0.01 * factors[1]
            gz = abs(_num(size[1])) * 0.01 * factors[2]
            sid = self._register_sub("BoxShape3D", ["size = " + _vec3_literal([gx, gy, gz])])
            self._add_shape_node(parent_path, "BoxCollision", _scaled_shape_mat(local, scale), sid)
        for sphere in collision.get("spheres") or []:
            radius = abs(_num(sphere.get("radius"))) if isinstance(sphere, dict) else 0.0
            if radius <= 0.0:
                continue
            # A sphere cannot express a non-uniform scale, so it settles for the mean --
            # the one shape where the bake stays an approximation.
            radius *= 0.01 * _uniform_factor(scale)
            sid = self._register_sub("SphereShape3D", ["radius = " + _f(radius)])
            local = _transform_dict_to_mat(sphere.get("godot_local_transform"))
            self._add_shape_node(parent_path, "SphereCollision",
                                 _scaled_shape_mat(local, scale), sid)
        for cap in collision.get("capsules") or []:
            cap_radius = abs(_num(cap.get("radius"))) if isinstance(cap, dict) else 0.0
            if cap_radius <= 0.0:
                continue
            local = _transform_dict_to_mat(cap.get("godot_local_transform"))
            # A Godot capsule runs along its local Y: Y stretches the cylinder, X and Z
            # stretch the radius -- and the radius takes only one of them.
            factors = _scaled_axis_factors(local[0], scale)
            radial = 0.5 * (factors[0] + factors[2])
            radius = cap_radius * 0.01 * radial
            length = abs(_num(cap.get("length"))) * factors[1]
            height = length * 0.01 + 2.0 * radius
            sid = self._register_sub("CapsuleShape3D",
                                     ["radius = " + _f(radius), "height = " + _f(height)])
            self._add_shape_node(parent_path, "CapsuleCollision",
                                 _scaled_shape_mat(local, scale), sid)
        for convex in collision.get("convex_hulls") or []:
            verts = convex.get("vertices") if isinstance(convex, dict) else None
            if not isinstance(verts, (list, tuple)):
                continue
            verts = [v for v in verts if isinstance(v, (list, tuple)) and len(v) >= 3]
            if not verts:
                continue
            local = _transform_dict_to_mat(convex.get("godot_local_transform"))
            # A hull is a raw point cloud, so it takes the body scale EXACTLY -- shear,
            # mirror and all -- expressed in the shape's own frame: B^-1 * S * B, which is
            # identity whenever there is nothing to bake.
            point_map = _scale_diag(scale)[0]
            if abs(_rows_determinant(local[0])) > 1e-12:
                point_map = _mat_compose(_mat_affine_inverse((local[0], [0.0, 0.0, 0.0])),
                                         _mat_compose(_scale_diag(scale),
                                                      (local[0], [0.0, 0.0, 0.0])))[0]
            floats = []
            for v in verts:
                # per-vertex glTF [x, z, y] * 0.01 remap (matches importer ConvexPolygonShape3D)
                p = (_num(v[0]) * 0.01, _num(v[2]) * 0.01, _num(v[1]) * 0.01)
                floats.extend(sum(point_map[i][k] * p[k] for k in range(3)) for i in range(3))
            body = ["points = PackedVector3Array(%s)" % ", ".join(_f(x) for x in floats)]
            sid = self._register_sub("ConvexPolygonShape3D", body)
            # Not _scaled_shape_mat(): point_map already mirrored the points.
            self._add_shape_node(parent_path, "ConvexCollision",
                                 (local[0], [local[1][i] * scale[i] for i in range(3)]), sid)

    def _add_shape_node(self, parent_path, name, local_mat, shape_id):
        props = ["transform = " + _mat_to_transform3d(local_mat),
                 'shape = SubResource("%s")' % shape_id]
        self._add_node(name, "CollisionShape3D", parent_path, props=props)

    # --- mesh instance node / placeholder ----------------------------------------------------
    def _mesh_res_path(self, mesh_key, mesh_name=None):
        """Return a verified res:// glTF path for mesh_key, falling back to the raw mesh
        name (v1 layouts, partial exports); None if missing on disk."""
        path = self._resolve_existing_res(self.models_res, str(mesh_key), _MODEL_EXTS)
        if path is None and mesh_name and mesh_name != mesh_key:
            path = self._resolve_existing_res(self.models_res, str(mesh_name), _MODEL_EXTS)
        return path

    # =========================================================================================
    # Section builders
    # =========================================================================================
    def build(self, scene_name):
        root_name = _sanitize_node_name(scene_name or "Scene")
        root_path = self._add_node(root_name, "Node3D", parent_path=None)

        self._build_actors(root_path)
        if self.options.get("lights"):
            self._build_lights(self._container(root_path, LIGHT_CONTAINER,
                                               self.layout.get("lights")))
        self._build_environment(root_path)  # post_process/fog/sky are always environment-worthy
        if self.options.get("decals"):
            self._build_decals(self._container(root_path, DECAL_CONTAINER,
                                               self.layout.get("decals")))
        if self.options.get("reflection_probes", True):
            self._build_reflection_probes(self._container(root_path, REFLECTION_PROBE_CONTAINER,
                                                          self.layout.get("reflection_probes")))
        if self.options.get("cameras", True):
            self._build_cameras(self._container(root_path, CAMERA_CONTAINER,
                                                self.layout.get("cameras")))
        if self.options.get("audio", True):
            self._build_audio(self._container(root_path, AUDIO_CONTAINER,
                                              self.layout.get("audio")))
        if self.layout.get("cables"):
            _warn("%d cable(s) skipped: their meshes cannot be baked into a static .tscn; "
                  "use the Godot addon importer." % len(self.layout["cables"]))
        if self.options.get("foliage"):
            self._build_foliage(self._container(root_path, FOLIAGE_CONTAINER,
                                                self.layout.get("foliage"), [NAV_SOURCE_GROUP]))
        if self.options.get("navigation"):
            nav = self.layout.get("navigation")
            nav_vols = nav.get("bounds_volumes") if isinstance(nav, dict) else None
            if nav_vols:
                self._build_navigation(self._container(root_path, NAVIGATION_CONTAINER, nav_vols))
        if self.options.get("landscape"):
            self._build_landscapes(root_path)

    def _container(self, root_path, name, entries, groups=None):
        """A Node3D grouping one feature's nodes, matching what the Godot addon's feature
        modules build (UnrealLights, UnrealDecals, UnrealFoliage, UnrealNavigation). A
        level is mostly static meshes, so without these the handful of nodes a user goes
        looking for is buried among thousands of props. Emitted at identity, so nothing
        below moves; skipped entirely when the feature is empty."""
        if not entries:
            return root_path
        return self._add_node(name, "Node3D", root_path, groups=groups)

    # --- actors ------------------------------------------------------------------------------
    def _resolve_folder_parent(self, root_path, folder_path, folder_cache):
        """Creates or reuses nested identity Node3D folders mirroring Unreal's World Outliner."""
        clean = str(folder_path or "").replace("\\", "/").strip()
        if not clean:
            return root_path
        parent = root_path
        key = ""
        for seg in clean.split("/"):
            seg = seg.strip()
            if not seg:
                continue
            key = seg if not key else (key + "/" + seg)
            if key in folder_cache:
                parent = folder_cache[key]
            else:
                parent = self._add_node(seg, "Node3D", parent)
                folder_cache[key] = parent
        return parent

    def _build_actors(self, scene_root_path):
        meshes_lib = self.layout.get("meshes") or {}
        emit_meta = bool(self.options.get("metadata"))
        preserve_folders = bool(self.options.get("preserve_folders", True))
        actors = [a for a in (self.layout.get("actors") or [])
                  if isinstance(a, dict) and (a.get("components") or [])]
        # Every mesh actor goes under one container -- see _container().
        root_path = self._container(scene_root_path, STATIC_MESH_CONTAINER, actors,
                                    [NAV_SOURCE_GROUP])
        folder_cache = {}
        for actor in actors:
            components = actor.get("components") or []
            actor_name = actor.get("name") or "Actor"
            actor_mat = _transform_dict_to_mat(actor.get("godot_transform"))
            actor_meta = self._actor_metadata_lines(actor)
            actor_parent = (self._resolve_folder_parent(root_path, actor.get("folder_path"), folder_cache)
                            if preserve_folders and actor.get("folder_path") else root_path)

            if len(components) == 1:
                self._build_single_component_actor(actor_parent, actor_name, actor_mat,
                                                   components[0], meshes_lib, actor, actor_meta, emit_meta)
            else:
                self._build_multi_component_actor(actor_parent, actor_name, actor_mat,
                                                  components, meshes_lib, actor_meta, emit_meta)

    def _component_mesh_key(self, comp):
        return comp.get("mesh_key") or comp.get("mesh_name") or ""

    def _build_single_component_actor(self, root_path, actor_name, actor_mat, comp,
                                      meshes_lib, actor, actor_meta, emit_meta):
        mesh_key = self._component_mesh_key(comp)
        world = _component_world_mat(comp, actor_mat)
        res_path = self._mesh_res_path(mesh_key, comp.get("mesh_name"))

        if res_path is None:
            # Missing mesh -> Marker3D placeholder at the component's world transform
            props = ["transform = " + _mat_to_transform3d(world)]
            meta = ['metadata/missing_mesh = "%s"' % _escape_string(mesh_key)] + actor_meta
            self._add_node("MISSING_" + _sanitize_node_name(mesh_key), "Marker3D",
                           root_path, props=props, metadata=meta)
            _warn("missing mesh '%s' for actor '%s' -> Marker3D placeholder" % (mesh_key, actor_name))
            return

        ext_id = self._register_ext("PackedScene", res_path)
        want_collision = comp.get("collision_enabled", True) is not False
        has_spline = isinstance(comp.get("spline_mesh"), dict) and bool(comp.get("spline_mesh"))
        collision = (meshes_lib.get(mesh_key) or {}).get("collision") if (want_collision and not has_spline) else None
        extra_meta = self._mesh_extra_metadata_lines(mesh_key, meshes_lib,
                                                     comp.get("mesh_name"))
        if has_spline:
            extra_meta.append("metadata/unreal_spline_mesh = true")
            _warn("actor '%s': spline mesh deformation cannot be baked into a static .tscn; "
                  "use the Godot addon importer for deformed spline geometry." % actor_name)

        # Re-seat the glTF mesh from the glTF axis order into the placement
        # convention (see _apply_mesh_axis_fix). Applied at the body, it carries
        # the mesh-local collision shapes along, keeping them hugging the mesh.
        mesh_place = _apply_mesh_axis_fix(world)

        if collision:
            # Collision shapes are mesh-local, so the body carries the component's
            # (axis-corrected) world transform -- minus any scale Jolt could not have
            # applied to the shapes, which the mesh instance under it takes instead.
            scale = _physics_body_scale(mesh_place)
            body_props = ["transform = " + _mat_to_transform3d(_physics_body_mat(mesh_place))]
            if comp.get("visible") is False:
                body_props.append("visible = false")
            body_path = self._add_node(actor_name, "StaticBody3D", root_path,
                                       props=body_props, metadata=actor_meta)
            self._emit_collision(body_path, collision, scale)
            inst_props = ["transform = " + _mat_to_transform3d(_scale_diag(scale))]
            inst_meta = (self._component_metadata_lines(comp) if emit_meta else []) + extra_meta
            self._add_node(_mesh_node_name(comp, mesh_key), None, body_path,
                           instance_id=ext_id, props=inst_props, metadata=inst_meta)
        else:
            # Direct visual-only instance at the component's world transform.
            # Merge actor + component tags into a single metadata/unreal_tags line
            # so Godot never sees duplicate keys in the same [node] block.
            props = ["transform = " + _mat_to_transform3d(mesh_place)]
            if comp.get("visible") is False:
                props.append("visible = false")
            meta = self._actor_metadata_lines(actor, extra_tags=comp.get("tags")) + extra_meta
            self._add_node(actor_name, None, root_path, instance_id=ext_id,
                           props=props, metadata=meta)

    def _build_multi_component_actor(self, root_path, actor_name, actor_mat, components,
                                     meshes_lib, actor_meta, emit_meta):
        # A scale on the actor is INHERITED by the bodies beneath it, where Jolt would
        # hit it again -- stripping it at the body alone would achieve nothing. Component
        # placements are absolute, so the actor frame is free: drop the unsafe scale here
        # and it reappears in each component's local transform, which is where
        # _emit_collision can bake it into the shapes.
        actor_frame = _physics_body_mat(actor_mat)
        parent_props = ["transform = " + _mat_to_transform3d(actor_frame)]
        actor_path = self._add_node(actor_name, "Node3D", root_path,
                                    props=parent_props, metadata=actor_meta)
        # Components are emitted under actor_path, so their world placement has to
        # be re-expressed relative to the actor.
        actor_inverse = _mat_affine_inverse(actor_frame)
        for comp in components:
            mesh_key = self._component_mesh_key(comp)
            comp_name = comp.get("name") or "Component"
            comp_mat = _mat_compose(actor_inverse, _component_world_mat(comp, actor_mat))
            res_path = self._mesh_res_path(mesh_key, comp.get("mesh_name"))
            comp_meta = self._component_metadata_lines(comp) if emit_meta else []

            if res_path is None:
                props = ["transform = " + _mat_to_transform3d(comp_mat)]
                meta = ['metadata/missing_mesh = "%s"' % _escape_string(mesh_key)] + comp_meta
                self._add_node("MISSING_" + _sanitize_node_name(mesh_key), "Marker3D",
                               actor_path, props=props, metadata=meta)
                continue

            ext_id = self._register_ext("PackedScene", res_path)
            want_collision = comp.get("collision_enabled", True) is not False
            has_spline = isinstance(comp.get("spline_mesh"), dict) and bool(comp.get("spline_mesh"))
            collision = (meshes_lib.get(mesh_key) or {}).get("collision") if (want_collision and not has_spline) else None
            extra_meta = self._mesh_extra_metadata_lines(mesh_key, meshes_lib,
                                                     comp.get("mesh_name"))
            if has_spline:
                extra_meta.append("metadata/unreal_spline_mesh = true")
                _warn("actor '%s.%s': spline mesh deformation cannot be baked into a static .tscn; "
                      "use the Godot addon importer for deformed spline geometry." % (actor_name, comp_name))
            # Re-seat the glTF mesh (and its collision) into the placement convention.
            mesh_place = _apply_mesh_axis_fix(comp_mat)
            if collision:
                scale = _physics_body_scale(mesh_place)
                body_props = ["transform = " + _mat_to_transform3d(_physics_body_mat(mesh_place))]
                if comp.get("visible") is False:
                    body_props.append("visible = false")
                body_path = self._add_node(comp_name, "StaticBody3D", actor_path,
                                           props=body_props, metadata=comp_meta)
                self._emit_collision(body_path, collision, scale)
                # The body already carries the component transform, so the mesh instance
                # under it only takes the scale the body had to give up.
                self._add_node(_mesh_node_name(comp, mesh_key), None, body_path,
                               instance_id=ext_id,
                               props=["transform = " + _mat_to_transform3d(_scale_diag(scale))],
                               metadata=extra_meta)
            else:
                props = ["transform = " + _mat_to_transform3d(mesh_place)]
                if comp.get("visible") is False:
                    props.append("visible = false")
                self._add_node(comp_name, None, actor_path, instance_id=ext_id,
                               props=props, metadata=comp_meta + extra_meta)

    # --- lights ------------------------------------------------------------------------------
    def _build_lights(self, root_path):
        """
        Mirrors import_environment.gd's _apply_lights property for property.
        The two must agree: exporting a .tscn and importing the same layout
        through the addon are meant to be interchangeable, and
        tests/test_tscn_writer.py pins them against each other.
        """
        for light in self.layout.get("lights") or []:
            if not isinstance(light, dict):
                continue
            ltype = str(light.get("type") or "point").lower()
            name = light.get("name") or "Light"
            mat = _transform_dict_to_mat(light.get("godot_transform"))
            props = ["transform = " + _mat_to_transform3d(mat)]

            color = list(light.get("color") or [1.0, 1.0, 1.0])[:3] or [1.0, 1.0, 1.0]
            while len(color) < 3:
                color.append(1.0)
            color = [_linear_to_srgb(_num(c, 1.0)) for c in color]
            kelvin = _num(light.get("temperature_kelvin"), 6500.0)
            if light.get("use_temperature") and kelvin > 0.0:
                k = _kelvin_to_rgb(kelvin)
                color = [color[i] * k[i] for i in range(3)]
            props.append("light_color = " + _srgb_literal(color))

            energy = _num(light.get("godot_energy"), 1.0) * self.light_energy_scale
            props.append("light_energy = " + _f(max(0.0, energy)))
            props.append("shadow_enabled = %s"
                         % ("true" if light.get("cast_shadows", True) else "false"))
            props.append("light_indirect_energy = " + _f(_num(light.get("indirect_intensity"), 1.0)))
            props.append("light_volumetric_fog_energy = "
                         + _f(_num(light.get("volumetric_scattering"), 1.0)))

            radius = _num(light.get("attenuation_radius_m"), DEFAULT_ATTENUATION_M)
            inverse_square = light.get("inverse_squared_falloff", True)
            source_radius = max(0.0, _num(light.get("source_radius_m"), 0.0))
            specular = max(0.0, _num(light.get("specular_scale"), 1.0))

            metadata = []
            if ltype == "directional":
                gtype = "DirectionalLight3D"
                props.append("light_specular = " + _f(specular * GODOT_DIRECTIONAL_SPECULAR))
                props.append("light_angular_distance = "
                             + _f(_clamp(_num(light.get("source_angle_deg"), 0.0), 0.0, 90.0)))
                shadow_distance = _num(light.get("shadow_distance_m"), 0.0)
                if shadow_distance > 0.0:
                    props.append("directional_shadow_max_distance = " + _f(shadow_distance))
            else:
                props.append("light_specular = " + _f(specular * GODOT_LOCAL_SPECULAR))
                if source_radius > 0.0:
                    props.append("light_size = " + _f(source_radius))
                if ltype == "spot":
                    gtype = "SpotLight3D"
                    props.append("spot_range = " + _f(max(0.01, radius)))
                    if inverse_square:
                        props.append("spot_attenuation = 2.0")
                    outer = _num(light.get("outer_cone_angle_deg"), 44.0)
                    inner = _num(light.get("inner_cone_angle_deg"), 0.0)
                    props.append("spot_angle = " + _f(_clamp(outer, 0.5, MAX_SPOT_ANGLE_DEG)))
                    props.append("spot_angle_attenuation = " + _f(_spot_softness(inner, outer)))
                else:  # point, rect (approximated by an omni) and unknown
                    gtype = "OmniLight3D"
                    props.append("omni_range = " + _f(max(0.01, radius)))
                    if inverse_square:
                        props.append("omni_attenuation = 2.0")
                    if ltype == "rect":
                        metadata.append("metadata/unreal_rect_light = true")
                        rect_size = light.get("rect_size_m")
                        if isinstance(rect_size, (list, tuple)) and len(rect_size) >= 2:
                            metadata.append("metadata/unreal_rect_size_m = Vector2(%s, %s)"
                                            % (_f(_num(rect_size[0], 0.0)),
                                               _f(_num(rect_size[1], 0.0))))
                            if source_radius <= 0.0:
                                props.append("light_size = " + _f(
                                    max(_num(rect_size[0], 0.0), _num(rect_size[1], 0.0)) * 0.5))

            fade_begin = light.get("distance_fade_begin_m")
            fade_length = light.get("distance_fade_length_m")
            if isinstance(fade_begin, (int, float)) and isinstance(fade_length, (int, float)):
                props.append("distance_fade_enabled = true")
                props.append("distance_fade_begin = " + _f(max(0.0, float(fade_begin))))
                props.append("distance_fade_length = " + _f(max(0.01, float(fade_length))))

            if light.get("mobility"):
                metadata.append('metadata/unreal_mobility = "%s"'
                                % _escape_string(light.get("mobility")))

            if light.get("visible") is False:
                props.append("visible = false")

            self._add_node(name, gtype, root_path, props=props, metadata=metadata)

    def _main_post_process(self):
        """The highest-priority unbound post-process volume drives the WorldEnvironment."""
        chosen = None
        for pv in self.layout.get("post_process") or []:
            if not isinstance(pv, dict):
                continue
            if not pv.get("unbound", False):
                continue
            if chosen is None or _num(pv.get("priority")) > _num(chosen.get("priority")):
                chosen = pv
        return chosen

    def _uses_lumen(self):
        settings = (self._main_post_process() or {}).get("settings") or {}
        return (settings.get("gi_method") or self.layout.get("gi_method")) == "lumen"

    # --- environment (post_process + height_fog + sky) ---------------------------------------
    def _build_environment(self, root_path):
        height_fog = self.layout.get("height_fog")
        sky_light = self.layout.get("sky_light")
        has_atmosphere = bool(self.layout.get("has_sky_atmosphere"))

        chosen = self._main_post_process()
        settings = (chosen or {}).get("settings") or {}

        want_sky = bool(sky_light) or has_atmosphere
        want_env = bool(chosen) or bool(height_fog) or want_sky
        if not want_env:
            return

        env_lines = []

        sky_id = None
        gradient = sky_light.get("gradient") if isinstance(sky_light, dict) else None
        if not isinstance(gradient, dict):
            gradient = None
        if want_sky:
            if gradient is not None:
                shader_id = self._register_sub("Shader", ['code = "%s"' % SKY_SHADER])
                tint = sky_light.get("color")
                tint = list(tint[:3]) if isinstance(tint, (list, tuple)) else []
                tint = [_num(c, 1.0) * _num(sky_light.get("intensity"), 1.0)
                        for c in tint + [1.0] * (3 - len(tint))]
                psm_id = self._register_sub(
                    "ShaderMaterial",
                    ['shader = SubResource("%s")' % shader_id]
                    + ["shader_parameter/%s = %s" % (key, _vec3_literal(
                        gradient.get(key) if isinstance(gradient.get(key), (list, tuple)) else []))
                       for key in ("top", "horizon", "ground")]
                    + ["shader_parameter/falloff = " + _f(gradient.get("falloff"), 6.67)]
                    + ["shader_parameter/light_scale = " + _vec3_literal(tint)])
            else:
                psm_id = self._register_sub("ProceduralSkyMaterial", [
                    "sky_horizon_color = Color(0.64625, 0.65575, 0.67075, 1)",
                    "ground_horizon_color = Color(0.64625, 0.65575, 0.67075, 1)",
                ])
            sky_id = self._register_sub("Sky", ['sky_material = SubResource("%s")' % psm_id])
            env_lines.append("background_mode = 2")
            env_lines.append('sky = SubResource("%s")' % sky_id)
            env_lines.append("ambient_light_source = 3")
            if isinstance(sky_light, dict) and gradient is None:
                if sky_light.get("color") is not None:
                    env_lines.append("ambient_light_color = " + _color_literal(sky_light.get("color")))
                env_lines.append("ambient_light_energy = "
                                 + _f(_clamp(_num(sky_light.get("intensity"), 1.0), 0.0, 16.0)))
        else:
            env_lines.append("background_mode = 1")
            env_lines.append("background_color = Color(0, 0, 0, 1)")

        if self._uses_lumen():
            env_lines.append("sdfgi_enabled = true")
            env_lines.append("sdfgi_y_scale = 2")
            env_lines.append("ssr_enabled = true")
            env_lines.append("ssr_fade_out = 0.0")

        # Tonemapper: unconditional, because Unreal never renders linear. Mirrors
        # import_environment.gd's UNREAL_TONEMAP (Environment.TONE_MAPPER_ACES == 3).
        env_lines.append("tonemap_mode = %d" % _TONEMAP_ACES)

        # Exposure. Mirrors import_environment.gd::_apply_exposure -- see the
        # constants there for why each branch does what it does.
        cam_attr_id = None
        exposure, cam_attr_lines = _exposure_for_settings(settings)
        white_temp = _num(settings.get("white_temp"), 6500.0)
        if abs(white_temp - 6500.0) > 1.0:
            _warn("post-process white balance (%d K) has no Godot setting and was not applied; "
                  "use an adjustment color-correction LUT" % int(white_temp))
        if exposure is not None:
            env_lines.append("tonemap_exposure = " + _f(exposure))
        if cam_attr_lines:
            cam_attr_id = self._register_sub("CameraAttributesPractical", cam_attr_lines)

        # Glow (bloom)
        if settings.get("bloom_intensity") is not None:
            env_lines.append("glow_enabled = true")
            env_lines.append("glow_intensity = " + _f(_num(settings.get("bloom_intensity"), 0.8)))
            bt = settings.get("bloom_threshold")
            if bt is not None and _num(bt) >= 0.0:
                env_lines.append("glow_hdr_threshold = " + _f(_num(bt)))

        # SSAO. The *2.0 and the 0.01 m floor match import_environment.gd; this
        # path used to write the raw UE intensity, so the same level came out
        # half as occluded through the .tscn exporter as through the addon.
        if settings.get("ao_intensity") is not None:
            env_lines.append("ssao_enabled = true")
            env_lines.append("ssao_intensity = "
                             + _f(_clamp(_num(settings.get("ao_intensity"), 0.5) * 2.0, 0.0, 16.0)))
            if settings.get("ao_radius") is not None:
                env_lines.append("ssao_radius = "
                                 + _f(max(0.01, _num(settings.get("ao_radius"), 200.0) * 0.01)))

        # Color adjustments (saturation / contrast are stored as [r,g,b,a]; Godot wants scalars)
        sat = settings.get("saturation")
        con = settings.get("contrast")
        if sat is not None or con is not None:
            env_lines.append("adjustment_enabled = true")
            if isinstance(sat, (list, tuple)) and sat:
                env_lines.append("adjustment_saturation = " + _f(_clamp(_avg3(sat), 0.01, 8.0)))
            if isinstance(con, (list, tuple)) and con:
                env_lines.append("adjustment_contrast = " + _f(_clamp(_avg3(con), 0.01, 8.0)))

        # Height fog -> Godot depth fog; mirrors import_environment.gd.
        if isinstance(height_fog, dict):
            env_lines.append("fog_enabled = true")
            density = max(0.0, _num(height_fog.get("fog_density"), 0.02))
            rate = density * FOG_DENSITY_SCALE
            start = _num(height_fog.get("start_distance_m"), 0.0)
            if start > 0.0 and rate > 0.0:
                env_lines.append("fog_mode = 1")
                env_lines.append("fog_density = " + _f(1.0 - math.exp(-FOG_DEPTH_RANGE)))
                env_lines.append("fog_depth_curve = 0.5")
                env_lines.append("fog_depth_begin = " + _f(start))
                env_lines.append("fog_depth_end = " + _f(start + FOG_DEPTH_RANGE / rate))
            else:
                env_lines.append("fog_density = " + _f(_clamp(rate, 0.0, 1.0)))
            color = height_fog.get("color")
            if isinstance(color, (list, tuple)) and len(color) >= 3:
                peak = max([1.0] + [_num(c) for c in color[:3]])
                env_lines.append("fog_light_energy = " + _f(peak))
                env_lines.append("fog_light_color = "
                                 + _color_literal([_num(c) / peak for c in color[:3]]))
            else:
                env_lines.append("fog_light_color = " + _srgb_literal([0.62, 0.7, 0.8]))
            falloff = _num(height_fog.get("fog_height_falloff"), 0.2)
            if gradient is not None:
                env_lines.append("fog_sky_affect = 0.0")  # The captured sky has its fog in it.
            else:
                env_lines.append("fog_sky_affect = " + _f(
                    1.0 - math.exp(-2.0 * density / falloff) if falloff > 0.0 else 1.0))

        env_id = self._register_sub("Environment", env_lines)
        env_props = ['environment = SubResource("%s")' % env_id]
        if cam_attr_id is not None:
            env_props.append('camera_attributes = SubResource("%s")' % cam_attr_id)
        self._add_node("WorldEnvironment", "WorldEnvironment", root_path, props=env_props)

    # --- decals ------------------------------------------------------------------------------
    def _build_decals(self, root_path):
        for decal in self.layout.get("decals") or []:
            if not isinstance(decal, dict):
                continue
            name = decal.get("name") or "Decal"
            mat = _transform_dict_to_mat(decal.get("godot_transform"))
            props = ["transform = " + _mat_to_transform3d(mat)]
            size = decal.get("size_m")
            if isinstance(size, (list, tuple)) and size:
                size = _decal_size_with_min_depth(
                    size, decal.get("godot_transform"),
                    self.options.get("decal_min_depth_m", DEFAULT_DECAL_MIN_DEPTH_M))
                props.append("size = " + _vec3_literal(size))
            props += ["upper_fade = 0.01", "lower_fade = 0.01"]
            if decal.get("sort_order") is not None:
                props.append("sorting_offset = " + _f(_num(decal.get("sort_order"))))
            # Mirrors import_environment.gd's _apply_decals -- the two paths must
            # produce the same Decal or a .tscn export and an addon import of the
            # same layout disagree.
            if decal.get("visible") is False:
                props.append("visible = false")
            modulate = decal.get("modulate")
            if isinstance(modulate, (list, tuple)) and modulate:
                # The addon bakes the grade into the texture, which clamps at white.
                grade = max(0.0, _num((decal.get("textures") or {}).get("brightness"), 1.0))
                modulate = [_num(c) * grade for c in modulate[:3]] + list(modulate[3:])
                props.append("modulate = " + _color_literal(modulate))
            fade_begin = decal.get("distance_fade_begin_m")
            fade_length = decal.get("distance_fade_length_m")
            if fade_begin is not None and fade_length is not None:
                props.append("distance_fade_enabled = true")
                props.append("distance_fade_begin = " + _f(max(_num(fade_begin), 0.0)))
                props.append("distance_fade_length = " + _f(max(_num(fade_length), 0.01)))

            textures = decal.get("textures") or {}
            # The addon import bakes an atlas crop into a new ImageTexture
            # (import_environment.gd's _crop_decal_texture). This writer only
            # emits references to files that already exist, so it cannot -- the
            # decal gets the whole sheet. Say so rather than diverge in silence.
            if textures.get("uv_rect"):
                _warn("decal '%s': material crops its texture to %s, which the .tscn "
                      "writer cannot bake -- the whole atlas will be bound. Use the "
                      "Godot addon importer for this level's decals."
                      % (name, textures.get("uv_rect")))
            if textures.get("hue_shift"):
                _warn("decal '%s': material shifts the hue of its texture, which the .tscn "
                      "writer cannot bake. Use the Godot addon importer." % name)
            for tex_key, godot_prop in (("albedo", "texture_albedo"), ("normal", "texture_normal"),
                                        ("orm", "texture_orm"), ("emission", "texture_emission")):
                tex_name = textures.get(tex_key)
                if not tex_name:
                    continue
                res_path = self._resolve_existing_res(self.textures_res, str(tex_name), _TEXTURE_EXTS)
                if res_path is None:
                    _warn("decal '%s': texture '%s' missing on disk -> property omitted"
                          % (name, tex_name))
                    continue
                tid = self._register_ext("Texture2D", res_path)
                props.append('%s = ExtResource("%s")' % (godot_prop, tid))

            self._add_node(name, "Decal", root_path, props=props)

    # --- reflection probes / cameras / audio -------------------------------------------------
    def _build_reflection_probes(self, root_path):
        for entry in self.layout.get("reflection_probes") or []:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name") or "ReflectionProbe"
            mat = _transform_dict_to_mat(entry.get("godot_transform"))
            sz = entry.get("size_m") or [10.0, 10.0, 10.0]
            size = [max(0.1, abs(_num(sz[i], 10.0)) if len(sz) > i else 10.0) for i in range(3)]
            props = [
                "transform = " + _mat_to_transform3d(mat),
                "update_mode = 0",
                "intensity = " + _f(_clamp(_num(entry.get("intensity"), 1.0), 0.0, 16.0)),
                "size = " + _vec3_literal(size),
                "box_projection = %s" % ("true" if entry.get("box_projection", True) else "false"),
            ]
            if entry.get("blend_distance_m") is not None:
                props.append("blend_distance = " + _f(max(0.0, _num(entry.get("blend_distance_m"), 0.0))))
            if self._uses_lumen():
                props.append("ambient_mode = 0")
            if entry.get("visible") is False:
                props.append("visible = false")
            meta = ['metadata/unreal_probe_shape = "%s"' % _escape_string(entry.get("shape") or "box")]
            self._add_node(name, "ReflectionProbe", root_path, props=props, metadata=meta)

    def _build_cameras(self, root_path):
        for entry in self.layout.get("cameras") or []:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name") or "Camera"
            mat = _transform_dict_to_mat(entry.get("godot_transform"))
            proj = str(entry.get("projection") or "perspective").lower()
            near = max(0.001, _num(entry.get("near_clip_m"), 0.05))
            far = max(near + 0.1, _num(entry.get("far_clip_m"), 4000.0))
            # keep_aspect = 0 (KEEP_WIDTH) matches Unreal's horizontal FieldOfView.
            props = [
                "transform = " + _mat_to_transform3d(mat),
                "keep_aspect = 0",
            ]
            if proj == "orthogonal":
                props.append("projection = 1")
                props.append("size = " + _f(max(0.05, _num(entry.get("ortho_width_m"), 5.12))))
            else:
                props.append("fov = " + _f(_clamp(_num(entry.get("fov_deg"), 90.0), 1.0, 179.0)))
            props.append("near = " + _f(near))
            props.append("far = " + _f(far))
            self._add_node(name, "Camera3D", root_path, props=props)

    def _build_audio(self, root_path):
        for entry in self.layout.get("audio") or []:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name") or "Audio"
            is_spatial = entry.get("is_spatialized", True) is not False
            props = []
            if is_spatial:
                mat = _transform_dict_to_mat(entry.get("godot_transform"))
                props.append("transform = " + _mat_to_transform3d(mat))
            props.append("volume_db = " + _f(_clamp(_num(entry.get("volume_db"), 0.0), -80.0, 24.0)))
            props.append("pitch_scale = " + _f(_clamp(_num(entry.get("pitch_scale"), 1.0), 0.01, 4.0)))
            if is_spatial:
                props.append("max_distance = " + _f(max(0.1, _num(entry.get("attenuation_radius_m"), 40.0))))
            if entry.get("auto_play", True):
                props.append("autoplay = true")
            sound_file = entry.get("sound_file")
            if sound_file:
                stem = os.path.splitext(str(sound_file))[0]
                res_path = self._resolve_existing_res(self.audio_res, stem, (".wav", ".ogg", ".mp3"))
                if res_path:
                    aid = self._register_ext("AudioStream", res_path)
                    props.append('stream = ExtResource("%s")' % aid)
            meta = []
            if entry.get("sound_name"):
                meta.append('metadata/unreal_sound_name = "%s"' % _escape_string(entry.get("sound_name")))
            if entry.get("looping") is True:
                meta.append("metadata/unreal_looping = true")
            gtype = "AudioStreamPlayer3D" if is_spatial else "AudioStreamPlayer"
            self._add_node(name, gtype, root_path, props=props, metadata=meta)

    # --- foliage -----------------------------------------------------------------------------
    def _build_foliage(self, root_path):
        for entry in self.layout.get("foliage") or []:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name") or "Foliage"
            mesh_key = entry.get("mesh_key") or entry.get("mesh_name") or ""
            flat = entry.get("godot_transforms") or []
            count = len(flat) // 12
            if entry.get("instance_count") is not None:
                count = max(0, min(int(_num(entry.get("instance_count"), count)), len(flat) // 12))

            vals = [_num(v) for v in flat[:count * 12]]
            chunks = _cull_chunks(vals, count, _num(entry.get("cull_end_m"), 0.0)) or [[]]
            for chunk_idx, members in enumerate(chunks):
                chunk_name = name if chunk_idx == 0 else "%s_%d" % (name, chunk_idx + 1)
                self._add_foliage_chunk(chunk_name, entry, mesh_key, vals, members, root_path)

    def _add_foliage_chunk(self, name, entry, mesh_key, vals, members, root_path):
        buffer_vals = []
        for i in members:
            f = vals[i * 12:i * 12 + 12]
            # schema stores basis COLUMNS then origin; MultiMesh wants 3x4 ROW-major.
            # Post-multiply the basis by the glTF axis correction (_MESH_AXIS_FIX)
            # so foliage meshes match the layout meshes: local X -> -Z, Y -> Y,
            # Z -> X means new column X = -old column Z, new Y = old Y, new Z = old X.
            bxx, bxy, bxz = -f[6], -f[7], -f[8]   # column X <- -column Z
            byx, byy, byz = f[3], f[4], f[5]      # column Y (unchanged)
            bzx, bzy, bzz = f[0], f[1], f[2]      # column Z <- column X
            ox, oy, oz = f[9], f[10], f[11]
            buffer_vals.extend((
                bxx, byx, bzx, ox,   # row 0 + origin.x
                bxy, byy, bzy, oy,   # row 1 + origin.y
                bxz, byz, bzz, oz,   # row 2 + origin.z
            ))
        actual_count = len(buffer_vals) // 12

        mm_lines = [
            "transform_format = 1",
            "instance_count = %d" % actual_count,
            "visible_instance_count = -1",
            "buffer = PackedFloat32Array(%s)" % ", ".join(_f(v) for v in buffer_vals),
        ]
        mm_id = self._register_sub("MultiMesh", mm_lines)

        props = ['multimesh = SubResource("%s")' % mm_id]

        # Rendering state, mirroring import_foliage.gd::apply. Grass is
        # routinely authored shadowless in Unreal, and UE's per-instance cull
        # pair becomes Godot's visibility range (fade only when UE fades).
        if entry.get("visible") is False:
            props.append("visible = false")
        if entry.get("cast_shadow") is False:
            props.append("cast_shadow = %d" % _SHADOW_CASTING_OFF)

        cull_end = entry.get("cull_end_m")
        if isinstance(cull_end, (int, float)) and float(cull_end) > 0.0:
            # Godot measures to the MultiMesh's centre; see _cull_chunks.
            radius = 0.0
            if members:
                axes = [[vals[i * 12 + a] for i in members] for a in (9, 10, 11)]
                radius = 0.5 * math.sqrt(sum((max(a) - min(a)) ** 2 for a in axes))
            props.append("visibility_range_end = " + _f(float(cull_end) + radius))
            cull_begin = entry.get("cull_begin_m")
            if isinstance(cull_begin, (int, float)) and 0.0 < float(cull_begin) < float(cull_end):
                props.append("visibility_range_end_margin = "
                             + _f(float(cull_end) - float(cull_begin)))
                props.append("visibility_range_fade_mode = %d" % _VISIBILITY_RANGE_FADE_SELF)

        metadata = ["metadata/unreal_foliage = true"]
        # Point the dock's "bind foliage meshes" pass at the source glTF (verified if present).
        res_path = self._mesh_res_path(mesh_key, entry.get("mesh_name"))
        if res_path is None:
            res_path = self.models_res + str(mesh_key) + ".gltf"  # best-effort hint
        metadata.append('metadata/source_model = "%s"' % _escape_string(res_path))
        metadata.append('metadata/unreal_mesh_key = "%s"' % _escape_string(mesh_key))
        metadata.append('metadata/unreal_foliage_source = "%s"'
                        % _escape_string(str(entry.get("source") or "foliage")))
        self._add_node(name, "MultiMeshInstance3D", root_path,
                       props=props, metadata=metadata)

    # --- navigation --------------------------------------------------------------------------
    def _build_navigation(self, root_path):
        nav = self.layout.get("navigation")
        if not isinstance(nav, dict):
            return
        # Defaults and clamps mirror import_gameplay.gd.
        agent_radius = max(0.05, _num(nav.get("agent_radius_m"), 0.35))
        agent_height = max(0.1, _num(nav.get("agent_height_m"), 1.92))
        agent_climb = max(0.0, _num(nav.get("agent_max_step_height_m"), 0.35))
        agent_slope = _clamp(_num(nav.get("max_slope_deg"), 44.0), 0.1, 89.9)
        cell_size = _clamp(_num(nav.get("cell_size_m"), 0.25), 0.01, 1.0)

        for idx, vol in enumerate(nav.get("bounds_volumes") or []):
            if not isinstance(vol, dict):
                continue
            raw = vol.get("extent_m")
            raw = raw if isinstance(raw, (list, tuple)) else []
            extent = [abs(_num(raw[i], 5.0)) if len(raw) > i else 5.0 for i in range(3)]
            nm_lines = [
                "agent_radius = " + _f(agent_radius),
                "agent_height = " + _f(agent_height),
                "agent_max_climb = " + _f(agent_climb),
                "agent_max_slope = " + _f(agent_slope),
                "cell_size = " + _f(cell_size),
                "geometry_parsed_geometry_type = %d" % _PARSED_GEOMETRY_BOTH,
                "geometry_source_geometry_mode = %d" % _SOURCE_GEOMETRY_GROUPS_WITH_CHILDREN,
                'geometry_source_group_name = &"%s"' % NAV_SOURCE_GROUP,
            ]
            if _vec_length(extent) > 0.01:
                nm_lines.append("filter_baking_aabb = AABB(%s)" % ", ".join(
                    _f(v) for v in [-e for e in extent] + [2.0 * e for e in extent]))
            nm_id = self._register_sub("NavigationMesh", nm_lines)
            props = ['navigation_mesh = SubResource("%s")' % nm_id]
            gt = vol.get("godot_transform")
            if isinstance(gt, dict):
                props.insert(0, "transform = " + _mat_to_transform3d(_transform_dict_to_mat(gt)))
            self._add_node(vol.get("name") or ("NavRegion_%d" % idx),
                           "NavigationRegion3D", root_path, props=props)

    # --- landscapes --------------------------------------------------------------------------
    def _build_landscapes(self, root_path):
        """Emits a placeholder Node3D per landscape, carrying every field the
        Godot addon's terrain importer consumes.

        Deliberately geometry-free: rebuilding the terrain means decoding a
        float EXR and generating a mesh or driving Terrain3D, none of which a
        text .tscn can express. The Godot addon does that (dock import with
        Terrain enabled). The metadata here is the complete handover -- keep it
        in step with import_terrain.gd's _store_terrain_metadata."""
        for lscape in self.layout.get("landscapes") or []:
            if not isinstance(lscape, dict):
                continue
            name = lscape.get("name") or "Landscape"
            props = []
            gt = lscape.get("godot_transform")
            if isinstance(gt, dict):
                props.append("transform = " + _mat_to_transform3d(_transform_dict_to_mat(gt)))
            if lscape.get("visible") is False:
                props.append("visible = false")

            metadata = ["metadata/unreal_landscape = true"]
            hm = lscape.get("heightmap_file")
            if hm:
                heightmap_res = self.terrain_res + os.path.basename(str(hm).replace("\\", "/"))
                # Key name matches import_terrain.gd's set_meta("heightmap_file").
                metadata.append('metadata/heightmap_file = "%s"' % _escape_string(heightmap_res))
            res = lscape.get("heightmap_resolution")
            if isinstance(res, (list, tuple)) and len(res) >= 2:
                metadata.append("metadata/heightmap_resolution = Vector2i(%d, %d)"
                                % (int(_num(res[0], 0)), int(_num(res[1], 0))))
            ws = lscape.get("world_size_m")
            if isinstance(ws, (list, tuple)) and ws:
                metadata.append("metadata/world_size_m = " + _vec2_literal(ws))
            wc = lscape.get("world_center_m")
            if isinstance(wc, (list, tuple)) and len(wc) >= 3:
                metadata.append("metadata/world_center_m = " + _vec3_literal(wc))
            hr = lscape.get("height_range_m")
            if isinstance(hr, (list, tuple)) and hr:
                metadata.append("metadata/height_range_m = " + _vec2_literal(hr))
            enc = lscape.get("height_encoding")
            if enc:
                metadata.append('metadata/height_encoding = "%s"' % _escape_string(enc))
            spacing = lscape.get("vertex_spacing_m")
            if spacing is not None:
                metadata.append("metadata/vertex_spacing_m = " + _f(_num(spacing, 1.0)))

            # The landscape material's own textures. Unreal's layer-blend graph
            # exposes no layer->texture link, so these are recorded as
            # candidates for the user to pair with the paint layers by hand.
            material = lscape.get("material")
            if isinstance(material, dict):
                all_tex = []
                albedos = []
                for tex in (material.get("textures") or []):
                    if not isinstance(tex, dict):
                        continue
                    name_str = str(tex.get("texture", ""))
                    all_tex.append(name_str)
                    if tex.get("role") == "albedo":
                        albedos.append(name_str)
                if all_tex:
                    metadata.append('metadata/landscape_material = "%s"'
                                    % _escape_string(material.get("name", "")))
                    metadata.append("metadata/landscape_textures = PackedStringArray(%s)"
                                    % ", ".join('"%s"' % _escape_string(t) for t in all_tex))
                if albedos:
                    metadata.append("metadata/landscape_albedo_textures = PackedStringArray(%s)"
                                    % ", ".join('"%s"' % _escape_string(t) for t in albedos))

            layers = lscape.get("layers")
            if isinstance(layers, (list, tuple)) and layers:
                layer_names = []
                weight_files = []
                for l in layers:
                    if isinstance(l, dict):
                        layer_names.append(str(l.get("name", "")))
                        wf = l.get("weightmap_file")
                        weight_files.append(self.terrain_res + os.path.basename(str(wf).replace("\\", "/"))
                                            if wf else "")
                    else:
                        layer_names.append(str(l))
                        weight_files.append("")
                metadata.append("metadata/weightmap_layers = PackedStringArray(%s)"
                                % ", ".join('"%s"' % _escape_string(n) for n in layer_names))
                if any(weight_files):
                    metadata.append("metadata/weightmap_files = PackedStringArray(%s)"
                                    % ", ".join('"%s"' % _escape_string(p) for p in weight_files))

            self._add_node(name, "Node3D", root_path, props=props, metadata=metadata,
                           groups=[NAV_SOURCE_GROUP])

    # =========================================================================================
    # Serialization
    # =========================================================================================
    def serialize(self):
        load_steps = 1 + len(self._ext_resources) + len(self._sub_resources)
        out = []
        out.append("[gd_scene load_steps=%d format=3]" % load_steps)
        out.append("")

        for eid, gtype, res_path in self._ext_resources:
            out.append('[ext_resource type="%s" path="%s" id="%s"]'
                       % (gtype, _escape_string(res_path), eid))
        if self._ext_resources:
            out.append("")

        for sid, gtype, body in self._sub_resources:
            out.append('[sub_resource type="%s" id="%s"]' % (gtype, sid))
            out.extend(body)
            out.append("")

        for node_lines in self._nodes:
            out.extend(node_lines)
            out.append("")

        text = "\n".join(out).rstrip("\n") + "\n"
        return text


def _avg3(arr):
    vals = [_num(x) for x in arr[:3]] if isinstance(arr, (list, tuple)) else []
    if not vals:
        return 1.0
    return sum(vals) / len(vals)


def _mesh_node_name(comp, mesh_key):
    """Name for the instanced-mesh child node under a StaticBody3D."""
    return _sanitize_node_name(mesh_key or comp.get("name") or "Mesh")


def write_tscn(layout_data, output_path, res_paths, options):
    """Write a Godot 4 .tscn scene from a schema-v2 layout dict. Never raises; returns True/False."""
    try:
        options = options or {}
        scene_name = options.get("scene_name") or (layout_data or {}).get("level_name") or "ImportedLevel"

        writer = _TscnWriter(layout_data, res_paths, options)
        writer.build(scene_name)
        text = writer.serialize()

        out_dir = os.path.dirname(output_path)
        if out_dir and not os.path.isdir(out_dir):
            os.makedirs(out_dir, exist_ok=True)
        with open(output_path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)

        _log("wrote scene '%s' (%d ext, %d sub, %d nodes) -> %s"
             % (scene_name, len(writer._ext_resources), len(writer._sub_resources),
                len(writer._nodes), output_path))
        return True
    except Exception as exc:  # never raise out of the entry point
        _err("write_tscn failed: %s" % exc)
        try:
            import traceback
            _err(traceback.format_exc())
        except Exception:
            pass
        return False
