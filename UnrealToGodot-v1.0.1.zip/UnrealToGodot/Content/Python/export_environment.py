"""
Unreal Engine Python Script
Exports Lights, Post-Process Volumes, Height Fog, Sky Light, Sky Atmosphere
presence, and Decal actors into the SCHEMA_V2.md "lights", "post_process",
"height_fog", "sky_light", "has_sky_atmosphere" and "decals" structures.

Entry point: collect_environment(all_actors, collected_textures) -> dict
See docs/SCHEMA_V2.md ("lights" / "post_process" / "height_fog" / "sky_light" /
"has_sky_atmosphere" / "decals" sections and the "Module contracts" table) for
the authoritative JSON layout this module must produce.

This module is exception-safe end-to-end: every actor is processed inside its
own try/except (logged via unreal.log_warning on failure) and the whole entry
point is wrapped again so a totally unexpected failure still returns the
(possibly partially filled) result dict rather than raising or bringing up an
editor dialog.

--------------------------------------------------------------------------
godot_energy heuristic (see docs/SCHEMA_V2.md "lights" section)
--------------------------------------------------------------------------
Unreal light intensities are expressed in very different units depending on
light type: directional lights are always authored in lux (illuminance),
while local lights (point/spot/rect) can be authored in any of
unreal.LightUnits {Unitless, Candelas, Lumens, EV, Nits} (ULocalLightComponent's
IntensityUnits). Godot's Light3D.light_energy is a small unitless multiplier
with no fixed physical scale -- its default of "1.0" is calibrated so Godot's
own default lights look reasonable.

The conversion runs in two steps.

**Step 1 -- normalise to candelas.** Every local-light unit is folded into
luminous intensity using Unreal's *own* factors, read out of
ULocalLightComponent::GetUnitsConversionFactor and the per-component
ComputeLightBrightness overrides (UE 5.7 source), not invented here:

    candelas  -> intensity
    unitless  -> intensity * 16 / (100*100)      # UE's "legacy scale of 16"
    lumens    -> intensity / (2*pi*(1-cos(half_cone)))   # point: cos=-1 -> /4pi
                 rect lights use /pi (cosine distribution over the panel)
    ev        -> 2**intensity                    # EV100ToLuminance, 1 m^2 implied
    nits      -> intensity * emissive_area_m2    # capsule area; rect: w*h

Doing this first is the whole point: before it, the same physical light
imported up to 625x brighter or 12x dimmer purely depending on which unit the
artist happened to author it in, because each unit had its own unrelated
divisor. They now agree with each other by construction.

**Step 2 -- map to light_energy** (further tunable at import time via
options.light_energy_scale):

    local (point/spot/rect) -> candelas / pi
    lux (directional)       -> intensity / 10.0

Local lights match exactly: a white surface 1 m away reflects cd/pi in Unreal, and
`light_energy` in Godot with the attenuation exponent at 2. Directional lights keep
the engine-default anchor (UE ships 10 lux, Godot energy 1.0), because a sunlit
Unreal level usually relies on auto exposure that the Godot scene does not have.

The raw `intensity` + `intensity_units` are always stored too, alongside the
normalised `intensity_candelas`, so the value can be re-derived or hand-tuned
on the Godot side.

--------------------------------------------------------------------------
Lights are collected per component
--------------------------------------------------------------------------
Like decals (below), lights are gathered by scanning every actor for
LightComponents rather than by matching actor classes. Keying off
unreal.PointLight and friends silently dropped every light living on a
Blueprint -- lamp props, ceiling fixtures, torch pickups -- which is where a
dressed level keeps most of them, and exported only the first light of any
actor carrying several. USkyLightComponent deliberately does not derive from
ULightComponent, so the sky light is not caught twice by this scan.

--------------------------------------------------------------------------
Decal axis fix-up (see docs/SCHEMA_V2.md "decals" section)
--------------------------------------------------------------------------
UE lays a decal's texture out with U along local **+Z** and V along local **+Y**
(Engine/Shaders/Private/DeferredDecal.usf: `SwizzlePos = DecalVector.zyx`), so the
image is upright for a viewer looking along local +X. Godot's Decal has U along
local +X, V along local +Z and projects along local **-Y**. `_decal_transform` folds
in the fix-up rotation that lines those axes up, and permutes the converted **scale**
by it too. See its docstring for the derivation.

Beyond the transform, a decal carries its colour (`modulate` = DecalColor *
material tint * opacity), its visibility, and a distance fade converted from
UE's screen-size fade. Decals are collected per DecalComponent rather than per
DecalActor, so Blueprint props with decal components export too.
"""

import math
import os

import unreal

import ue2g_common
from export_level_to_json import extract_material_parameters


# Optional/engine-version-dependent classes. Resolved once at import time
# (via getattr, which never raises) so that per-actor isinstance() checks
# never blow up on older Unreal versions that lack RectLight/SkyAtmosphere.
_RECT_LIGHT_COMPONENT = getattr(unreal, "RectLightComponent", None)
_SKY_ATMOSPHERE_CLASS = getattr(unreal, "SkyAtmosphere", None)

# Unreal's "legacy scale of 16" over its cm^2 -> m^2 factor: the exact figure
# ULocalLightComponent::GetUnitsConversionFactor uses for Unitless -> Candelas.
_UNITLESS_TO_CANDELA = 16.0 / (100.0 * 100.0)

# Unreal's physical units per Godot light_energy; see the module docstring.
_CANDELA_PER_GODOT_ENERGY = math.pi
_LUX_PER_GODOT_ENERGY = 10.0


# ---------------------------------------------------------------------------
# Small defensive helpers
# ---------------------------------------------------------------------------

def _safe_label(actor):
    """Best-effort human readable name for logging/naming; never raises."""
    try:
        return actor.get_actor_label()
    except Exception:
        try:
            return actor.get_name()
        except Exception:
            return "<unknown actor>"


def _f(value, default=0.0):
    """Defensive float coercion; None/failed conversions fall back to default."""
    if value is None:
        return default
    try:
        return float(value)
    except Exception:
        return default


def _b(value, default=False):
    """Defensive bool coercion; None/failed conversions fall back to default."""
    if value is None:
        return default
    try:
        return bool(value)
    except Exception:
        return default


def _log_actor_warning(actor, context, err):
    unreal.log_warning(
        "export_environment: {} on '{}': {}".format(context, _safe_label(actor), err)
    )


def _actor_is_hidden(actor):
    """True when the actor itself is hidden in editor or hidden in game."""
    if actor is None:
        return False
    try:
        if hasattr(actor, "is_hidden_ed") and bool(actor.is_hidden_ed()):
            return True
    except Exception:
        pass
    return _b(ue2g_common.safe_get_prop(actor, "hidden", False), False)


# ---------------------------------------------------------------------------
# Lights
# ---------------------------------------------------------------------------

def _light_type_of(comp):
    """
    Classifies a LightComponent into one of the 4 supported light types, or
    None if it is not one of them. Order matters: USpotLightComponent derives
    from UPointLightComponent, so the more specific subclass must be checked
    first. (URectLightComponent does *not* derive from UPointLightComponent --
    verified against UE 5.7 -- but is checked first anyway so the ordering
    stays correct if that ever changes.)
    """
    if _RECT_LIGHT_COMPONENT is not None and isinstance(comp, _RECT_LIGHT_COMPONENT):
        return "rect"
    if isinstance(comp, unreal.SpotLightComponent):
        return "spot"
    if isinstance(comp, unreal.PointLightComponent):
        return "point"
    if isinstance(comp, unreal.DirectionalLightComponent):
        return "directional"
    return None


def _map_intensity_units(enum_val):
    """Maps an unreal.LightUnits enum value to the schema's unit string."""
    if enum_val is None:
        return "unknown"
    try:
        name = enum_val.name
    except Exception:
        name = str(enum_val)
    name = name.upper()
    # UNITLESS is tested first on purpose: it contains "NIT", so a substring
    # test for nits would claim every default-authored light as a luminance.
    if "UNITLESS" in name:
        return "unitless"
    if "CANDELA" in name:
        return "candela"
    if "LUMEN" in name:
        return "lumens"
    if "NIT" in name:
        return "nits"
    if "EV" in name:
        return "ev"
    return "unknown"


def _emissive_area_m2(comp, light_type):
    """
    The emitting surface area UE uses to turn nits (luminance) into candelas.

    Mirrors the ComputeLightBrightness overrides: a rect light emits from its
    source panel, a point/spot light from a capsule of SourceRadius and
    SourceLength. Both are authored in cm, so the cm^2 area is scaled to m^2.
    """
    if light_type == "rect":
        width = _f(ue2g_common.safe_get_prop(comp, "source_width", 0.0), 0.0)
        height = _f(ue2g_common.safe_get_prop(comp, "source_height", 0.0), 0.0)
        area_cm2 = width * height
    else:
        radius = _f(ue2g_common.safe_get_prop(comp, "source_radius", 0.0), 0.0)
        length = _f(ue2g_common.safe_get_prop(comp, "source_length", 0.0), 0.0)
        area_cm2 = 4.0 * math.pi * radius * (radius + 0.5 * length)
    return area_cm2 * ue2g_common.CM_TO_M * ue2g_common.CM_TO_M


def _intensity_in_candelas(comp, light_type, intensity, units, outer_cone_angle_deg):
    """
    Normalises a local light's authored intensity to candelas using Unreal's
    own unit factors. See the module docstring for the table and its source.
    """
    intensity = _f(intensity, 0.0)

    if units == "candela":
        return intensity
    if units == "ev":
        # EV is logarithmic, and legitimately negative for dim lights.
        try:
            return 2.0 ** intensity
        except Exception:
            return 0.0
    if units == "lumens":
        if light_type == "rect":
            return intensity / math.pi
        cos_half_cone = -1.0
        if light_type == "spot" and outer_cone_angle_deg is not None:
            # Clamp away from 0 deg so 1 - cos(0) never divides by zero.
            cos_half_cone = math.cos(math.radians(
                min(max(_f(outer_cone_angle_deg, 44.0), 0.5), 89.9)))
        return intensity / max(2.0 * math.pi * (1.0 - cos_half_cone), 1e-6)
    if units == "nits":
        return intensity * _emissive_area_m2(comp, light_type)

    # "unitless", "unknown", and every light with inverse-square falloff
    # switched off (where UE ignores IntensityUnits entirely) share UE's
    # legacy scale of 16.
    return intensity * _UNITLESS_TO_CANDELA


def _compute_godot_energy(intensity_candelas, lux=None):
    """godot_energy heuristic; see the module docstring for the rationale."""
    if lux is not None:
        return _f(lux, 0.0) / _LUX_PER_GODOT_ENERGY
    return _f(intensity_candelas, 0.0) / _CANDELA_PER_GODOT_ENERGY


def _light_distance_fade(comp):
    """
    Converts UE's MaxDrawDistance/MaxDistanceFadeRange (cm) into Godot
    (distance_fade_begin, distance_fade_length) metres, or (None, None) when
    the light is never culled. UE fades out over the last MaxDistanceFadeRange
    before MaxDrawDistance, which is exactly Godot's begin/length pair.
    """
    max_draw_cm = _f(ue2g_common.safe_get_prop(comp, "max_draw_distance", 0.0), 0.0)
    if max_draw_cm <= 0.0:
        return None, None
    fade_range_cm = _f(ue2g_common.safe_get_prop(comp, "max_distance_fade_range", 0.0), 0.0)

    end_m = max_draw_cm * ue2g_common.CM_TO_M
    length_m = max(0.01, fade_range_cm * ue2g_common.CM_TO_M)
    return max(0.0, end_m - length_m), length_m


def _light_mobility(comp):
    """'static' | 'stationary' | 'movable' | None -- diagnostic only."""
    mobility = ue2g_common.safe_get_prop(comp, "mobility", None)
    if mobility is None:
        return None
    try:
        name = mobility.name
    except Exception:
        name = str(mobility)
    name = name.upper()
    for candidate in ("STATIONARY", "STATIC", "MOVABLE"):
        if candidate in name:
            return candidate.lower()
    return None


def _light_components(actor):
    """Every LightComponent on an actor, in declaration order; never raises."""
    try:
        comps = actor.get_components_by_class(unreal.LightComponent)
    except Exception as e:
        _log_actor_warning(actor, "failed to list LightComponents", e)
        return []
    return [c for c in (comps or []) if c is not None]


def _build_light_entries(actor):
    """
    One schema entry per supported LightComponent on `actor`.

    Actors carrying more than one light get the component name appended so the
    Godot node names stay unique and traceable -- the same rule decals use.
    """
    comps = [c for c in _light_components(actor) if _light_type_of(c) is not None]
    label = _safe_label(actor)
    entries = []
    for comp in comps:
        name = label
        if len(comps) > 1:
            name = "{}_{}".format(label, ue2g_common.safe_get_name(comp))
        try:
            entry = _build_light_entry(actor, comp, name)
        except Exception as e:
            _log_actor_warning(actor, "failed to build light entry", e)
            continue
        if entry is not None:
            entries.append(entry)
    return entries


def _build_light_entry(actor, light_comp, name):
    light_type = _light_type_of(light_comp)
    if light_type is None:
        return None
    if _b(ue2g_common.safe_get_prop(light_comp, "is_editor_only", False), False):
        return None

    intensity = _f(ue2g_common.safe_get_prop(light_comp, "intensity", None), 0.0)

    color_raw = ue2g_common.safe_get_prop(light_comp, "light_color", None)
    color = ue2g_common.linear_color_to_list(color_raw) if color_raw is not None else [1.0, 1.0, 1.0]

    attenuation_radius_m = None
    source_radius_m = None
    inner_cone_angle_deg = None
    outer_cone_angle_deg = None
    source_angle_deg = None
    shadow_distance_m = None
    rect_size_m = None
    intensity_candelas = None
    inverse_squared = True

    if light_type == "directional":
        # Directional lights have no IntensityUnits property; UE always
        # authors/interprets their intensity as lux (illuminance).
        intensity_units = "lux"
        godot_energy = _compute_godot_energy(None, lux=intensity)

        # The angular diameter of the sun disc: UE calls it LightSourceAngle,
        # Godot light_angular_distance, and both are degrees.
        angle = ue2g_common.safe_get_prop(light_comp, "light_source_angle", None)
        if angle is not None:
            source_angle_deg = _f(angle)

        shadow_cm = _f(ue2g_common.safe_get_prop(
            light_comp, "dynamic_shadow_distance_movable_light", 0.0), 0.0)
        if shadow_cm <= 0.0:
            shadow_cm = _f(ue2g_common.safe_get_prop(
                light_comp, "dynamic_shadow_distance_stationary_light", 0.0), 0.0)
        if shadow_cm > 0.0:
            shadow_distance_m = shadow_cm * ue2g_common.CM_TO_M
    else:
        radius = ue2g_common.safe_get_prop(light_comp, "attenuation_radius", None)
        if radius is not None:
            attenuation_radius_m = _f(radius) * ue2g_common.CM_TO_M

        src_radius = ue2g_common.safe_get_prop(light_comp, "source_radius", None)
        if src_radius is not None:
            source_radius_m = _f(src_radius) * ue2g_common.CM_TO_M

        intensity_units = _map_intensity_units(
            ue2g_common.safe_get_prop(light_comp, "intensity_units", None)
        )

        if light_type == "spot":
            inner = ue2g_common.safe_get_prop(light_comp, "inner_cone_angle", None)
            outer = ue2g_common.safe_get_prop(light_comp, "outer_cone_angle", None)
            if inner is not None:
                inner_cone_angle_deg = _f(inner)
            if outer is not None:
                outer_cone_angle_deg = _f(outer)

        if light_type == "rect":
            rect_size_m = [
                _f(ue2g_common.safe_get_prop(light_comp, "source_width", 0.0), 0.0)
                * ue2g_common.CM_TO_M,
                _f(ue2g_common.safe_get_prop(light_comp, "source_height", 0.0), 0.0)
                * ue2g_common.CM_TO_M,
            ]

        # With inverse-square falloff off, UE ignores IntensityUnits and reads
        # Intensity on its legacy scale, so the unit conversion must too.
        inverse_squared = _b(ue2g_common.safe_get_prop(
            light_comp, "use_inverse_squared_falloff", True), True)
        units_for_conversion = intensity_units if inverse_squared else "unitless"

        intensity_candelas = _intensity_in_candelas(
            light_comp, light_type, intensity, units_for_conversion, outer_cone_angle_deg)
        # shortcut: an IES profile keeps only its peak, and only on spots, where the cone
        # bounds it; carry the profile's shape if a pack relies on it.
        ies = ue2g_common.safe_get_prop(light_comp, "ies_texture", None)
        if light_type == "spot" and ies is not None:
            intensity_candelas *= _f(ue2g_common.safe_get_prop(ies, "texture_multiplier", 1.0), 1.0)
        godot_energy = _compute_godot_energy(intensity_candelas)

        if intensity > 0.0 and intensity_candelas <= 0.0 and units_for_conversion == "nits":
            _log_actor_warning(
                actor, "light exports black",
                "'{}' is authored in nits but has no emissive area (source "
                "radius/width are 0), which Unreal also renders as no light"
                .format(name))

    temperature = ue2g_common.safe_get_prop(light_comp, "temperature", None)
    fade_begin, fade_length = _light_distance_fade(light_comp)

    # A light switched off in game, or excluded from the world entirely, is
    # content the level deliberately disabled; a Godot node that ignores that
    # arrives lit.
    visible = (_b(ue2g_common.safe_get_prop(light_comp, "visible", True), True)
               and not _b(ue2g_common.safe_get_prop(light_comp, "hidden_in_game", False), False)
               and not _actor_is_hidden(actor)
               and _b(ue2g_common.safe_get_prop(light_comp, "affects_world", True), True))

    return {
        "name": name,
        "type": light_type,
        "godot_transform": ue2g_common.unreal_to_godot_transform(
            _component_world_transform(actor, light_comp)),
        "color": color,
        "intensity": intensity,
        "intensity_units": intensity_units,
        "intensity_candelas": intensity_candelas,
        "inverse_squared_falloff": inverse_squared,
        "godot_energy": godot_energy,
        "temperature_kelvin": _f(temperature) if temperature is not None else None,
        "use_temperature": _b(ue2g_common.safe_get_prop(light_comp, "use_temperature", False), False),
        "cast_shadows": _b(ue2g_common.safe_get_prop(light_comp, "cast_shadows", True), True),
        "attenuation_radius_m": attenuation_radius_m,
        "source_radius_m": source_radius_m,
        "source_angle_deg": source_angle_deg,
        "shadow_distance_m": shadow_distance_m,
        "rect_size_m": rect_size_m,
        "inner_cone_angle_deg": inner_cone_angle_deg,
        "outer_cone_angle_deg": outer_cone_angle_deg,
        "indirect_intensity": _f(
            ue2g_common.safe_get_prop(light_comp, "indirect_lighting_intensity", None), 1.0
        ),
        "specular_scale": _f(
            ue2g_common.safe_get_prop(light_comp, "specular_scale", None), 1.0
        ),
        "volumetric_scattering": _f(
            ue2g_common.safe_get_prop(light_comp, "volumetric_scattering_intensity", None), 1.0
        ),
        "distance_fade_begin_m": fade_begin,
        "distance_fade_length_m": fade_length,
        "mobility": _light_mobility(light_comp),
        "visible": visible,
    }


# ---------------------------------------------------------------------------
# Post Process Volume
# ---------------------------------------------------------------------------

def _pp_field(settings, override_prop, value_prop, transform=None):
    """
    Reads a single PostProcessSettings field, but only if its matching
    override_* flag is True (per SCHEMA_V2.md: "Only settings whose
    override_* flag is set in Unreal are non-null."). Returns None otherwise.
    """
    if settings is None:
        return None
    override_flag = ue2g_common.safe_get_prop(settings, override_prop, False)
    if not override_flag:
        return None
    value = ue2g_common.safe_get_prop(settings, value_prop, None)
    if value is None:
        return None
    if transform is not None:
        try:
            return transform(value)
        except Exception:
            return None
    return _f(value, None)


def _vec4_to_list(v):
    """Converts an unreal.Vector4 (or similarly-shaped) value to [x,y,z,w]."""
    try:
        return [float(v.x), float(v.y), float(v.z), float(v.w)]
    except Exception:
        try:
            return [float(v.r), float(v.g), float(v.b), float(v.a)]
        except Exception:
            return None


def _map_exposure_method(value):
    """Maps unreal.AutoExposureMethod (Histogram/Basic/Manual) to schema strings."""
    try:
        name = value.name
    except Exception:
        name = str(value)
    name = name.upper()
    if "MANUAL" in name:
        return "manual"
    return "auto"


def _map_gi_method(value):
    """unreal.DynamicGlobalIlluminationMethod, or its console variable, to a schema string."""
    return "lumen" if value == 1 or "LUMEN" in str(value).upper() else "other"


def _project_gi_method():
    get_cvar = getattr(getattr(unreal, "SystemLibrary", None),
                       "get_console_variable_int_value", None)
    return _map_gi_method(get_cvar("r.DynamicGlobalIlluminationMethod")) if get_cvar else None


def _exposure_luminance(value):
    """
    Min/max exposure brightness in cd/m^2. Projects with the extended luminance
    range (the UE 5 default) author it as EV100, where Unreal's exposure is
    1 / (1.2 * 2^EV); consumers compute 0.18 / luminance, hence the 0.18.
    """
    value = _f(value, None)
    system = getattr(unreal, "SystemLibrary", None)
    get_cvar = getattr(system, "get_console_variable_int_value", None)
    if value is None or get_cvar is None:
        return value
    if get_cvar("r.DefaultFeature.AutoExposure.ExtendDefaultLuminanceRange"):
        return 0.18 * 1.2 * 2.0 ** value
    return value


def _manual_exposure_luminance(settings):
    """
    What min == max brightness has to be to lock exposure where Unreal's manual
    mode does: 1 / (L * 2^EV100), L being 1.2 (1.0 without the extended luminance
    range). EV100 is the physical camera's, or 0 when the volume switches that off.
    None unless the volume sets the manual method.
    """
    if _pp_field(settings, "override_auto_exposure_method", "auto_exposure_method",
                 _map_exposure_method) != "manual":
        return None
    ev100 = 0.0
    if _pp_field(settings, "override_auto_exposure_apply_physical_camera_exposure",
                 "auto_exposure_apply_physical_camera_exposure", bool) is not False:
        def _camera(name, default):
            value = _pp_field(settings, "override_" + name, name)
            return value if value and value > 0.0 else default
        ev100 = math.log(_camera("depth_of_field_fstop", 4.0) ** 2
                         * _camera("camera_shutter_speed", 60.0)
                         * 100.0 / _camera("camera_iso", 100.0), 2)
    get_cvar = getattr(getattr(unreal, "SystemLibrary", None),
                       "get_console_variable_int_value", None)
    extended = get_cvar is None or get_cvar("r.DefaultFeature.AutoExposure.ExtendDefaultLuminanceRange")
    return 0.18 * (1.2 if extended else 1.0) * 2.0 ** ev100


def _size_to_godot(v):
    """
    Converts an Unreal extent/size vector (cm, always non-negative
    half-extents) to Godot meters using the same axis reassignment as
    translations (Godot_x=UE_y, Godot_y=UE_z, Godot_z=UE_x) but WITHOUT the
    sign flip used for directional translations, since an extent has no
    direction to reverse.
    """
    return [
        _f(v.y) * ue2g_common.CM_TO_M,
        _f(v.z) * ue2g_common.CM_TO_M,
        _f(v.x) * ue2g_common.CM_TO_M,
    ]


def _build_post_process_entry(actor):
    if not _b(ue2g_common.safe_get_prop(actor, "enabled", True), True):
        return None
    blend_weight = _f(ue2g_common.safe_get_prop(actor, "blend_weight", 1.0), 1.0)
    if blend_weight <= 0.0:
        return None
    settings = ue2g_common.safe_get_prop(actor, "settings", None)
    unbound = ue2g_common.safe_get_prop(actor, "unbound", True)
    priority = ue2g_common.safe_get_prop(actor, "priority", 0.0)

    extent_m = [0.0, 0.0, 0.0]
    try:
        bounds = actor.get_actor_bounds(False)
        box_extent = bounds[1]
        extent_m = _size_to_godot(box_extent)
    except Exception as e:
        _log_actor_warning(actor, "could not read actor bounds for PostProcessVolume", e)

    settings_out = {
        "bloom_intensity": _pp_field(settings, "override_bloom_intensity", "bloom_intensity"),
        "bloom_threshold": _pp_field(settings, "override_bloom_threshold", "bloom_threshold"),
        "ao_intensity": _pp_field(settings, "override_ambient_occlusion_intensity", "ambient_occlusion_intensity"),
        "ao_radius": _pp_field(settings, "override_ambient_occlusion_radius", "ambient_occlusion_radius"),
        "exposure_bias": _pp_field(settings, "override_auto_exposure_bias", "auto_exposure_bias"),
        "exposure_method": _pp_field(
            settings, "override_auto_exposure_method", "auto_exposure_method", _map_exposure_method
        ),
        # The auto-exposure adaptation range, in cd/m^2. Shipping only the
        # BIAS was not enough: a volume that locks exposure by setting
        # min_brightness == max_brightness (the standard "manual exposure"
        # idiom, and the single most visually dominant setting a grade can
        # carry) overrides NEITHER the bias nor the method, so the whole grade
        # exported as null and Godot fell back to a linear tonemapper.
        "exposure_min_brightness": _pp_field(
            settings, "override_auto_exposure_min_brightness", "auto_exposure_min_brightness",
            _exposure_luminance),
        "exposure_max_brightness": _pp_field(
            settings, "override_auto_exposure_max_brightness", "auto_exposure_max_brightness",
            _exposure_luminance),
        "exposure_speed_up": _pp_field(
            settings, "override_auto_exposure_speed_up", "auto_exposure_speed_up"),
        "exposure_speed_down": _pp_field(
            settings, "override_auto_exposure_speed_down", "auto_exposure_speed_down"),
        "white_temp": _pp_field(settings, "override_white_temp", "white_temp"),
        "saturation": _pp_field(settings, "override_color_saturation", "color_saturation", _vec4_to_list),
        "contrast": _pp_field(settings, "override_color_contrast", "color_contrast", _vec4_to_list),
        "gain": _pp_field(settings, "override_color_gain", "color_gain", _vec4_to_list),
        "gamma": _pp_field(settings, "override_color_gamma", "color_gamma", _vec4_to_list),
        "gi_method": _pp_field(settings, "override_dynamic_global_illumination_method",
                               "dynamic_global_illumination_method", _map_gi_method),
        "vignette_intensity": _pp_field(settings, "override_vignette_intensity", "vignette_intensity"),
    }

    manual = _manual_exposure_luminance(settings)
    if manual is not None:
        settings_out["exposure_min_brightness"] = settings_out["exposure_max_brightness"] = manual

    return {
        "name": _safe_label(actor),
        "unbound": _b(unbound, True),
        "priority": _f(priority, 0.0),
        "godot_transform": ue2g_common.actor_godot_transform(actor),
        "extent_m": extent_m,
        "settings": settings_out,
    }


# ---------------------------------------------------------------------------
# Height Fog / Sky Light
# ---------------------------------------------------------------------------

def _build_height_fog(actor):
    try:
        comp = actor.get_component_by_class(unreal.ExponentialHeightFogComponent)
    except Exception as e:
        _log_actor_warning(actor, "failed to get ExponentialHeightFogComponent", e)
        comp = None
    if comp is None:
        return None
    if (not _b(ue2g_common.safe_get_prop(comp, "visible", True), True)
            or _b(ue2g_common.safe_get_prop(comp, "hidden_in_game", False), False)
            or _actor_is_hidden(actor)):
        return None

    density = ue2g_common.safe_get_prop(comp, "fog_density", None)
    falloff = ue2g_common.safe_get_prop(comp, "fog_height_falloff", None)
    # Renamed in UE 5; the old name reads as None there.
    color_raw = ue2g_common.safe_get_prop(comp, "fog_inscattering_luminance", None)
    if color_raw is None:
        color_raw = ue2g_common.safe_get_prop(comp, "fog_inscattering_color", None)
    color = ue2g_common.linear_color_to_list(color_raw) if color_raw is not None else [1.0, 1.0, 1.0]
    start_distance = ue2g_common.safe_get_prop(comp, "start_distance", None)

    return {
        "fog_density": _f(density, 0.02),
        "fog_height_falloff": _f(falloff, 0.2),
        "color": color,
        "start_distance_m": _f(start_distance, 0.0) * ue2g_common.CM_TO_M,
    }


# How fast the horizon color gives way to the zenith's; 6.67 is Godot's procedural sky.
_SKY_FALLOFFS = (1.5, 3.0, 6.67, 10.0, 14.0, 20.0, 30.0)
_SKY_CAPTURE_SIZE = 32


def _fit_sky_gradient(samples):
    """
    Horizon color, zenith color and falloff of the two-color sky that best matches the
    samples, (sine of elevation, weight, (r, g, b)) above the horizon. Least squares, so
    the total light is the samples'.
    """
    cap = sorted(sum(rgb) for _, _, rgb in samples)[int(len(samples) * 0.98)]
    best = None
    for falloff in _SKY_FALLOFFS:
        s_hh = s_ht = s_tt = 0.0
        s_hv, s_tv, s_vv = [0.0] * 3, [0.0] * 3, 0.0
        for sine, weight, rgb in samples:
            h = (1.0 - math.asin(min(sine, 1.0)) / (0.5 * math.pi)) ** falloff
            t = 1.0 - h
            # A sun disc would count twice: its light is a directional light.
            scale = min(1.0, cap / max(sum(rgb), 1e-9))
            s_hh += weight * h * h
            s_ht += weight * h * t
            s_tt += weight * t * t
            for i in range(3):
                v = rgb[i] * scale
                s_hv[i] += weight * h * v
                s_tv[i] += weight * t * v
                s_vv += weight * v * v
        det = s_hh * s_tt - s_ht * s_ht
        if abs(det) <= 1e-12 or abs(s_tt) <= 1e-12:
            continue
        horizon = [max(0.0, (s_tt * hv - s_ht * tv) / det) for hv, tv in zip(s_hv, s_tv)]
        top = [max(0.0, (tv - s_ht * h) / s_tt) for tv, h in zip(s_tv, horizon)]
        error = s_vv + sum(
            h * h * s_hh + t * t * s_tt + 2.0 * (h * t * s_ht - h * hv - t * tv)
            for h, t, hv, tv in zip(horizon, top, s_hv, s_tv))
        if best is None or error < best[0]:
            best = (error, horizon, top, falloff)
    if best is None:
        w_sum = sum(w for _, w, _ in samples) or 1.0
        avg = [max(0.0, sum(w * rgb[i] for _, w, rgb in samples) / w_sum) for i in range(3)]
        return avg, list(avg), _SKY_FALLOFFS[0]
    return best[1:]


def _capture_sky(actor, comp):
    """
    Renders what the sky light sees (everything past its sky distance threshold) and
    returns {"top", "horizon", "ground"}, linear cd/m^2, and "falloff", or None when nothing can be
    rendered (a commandlet).

    shortcut: a sky light with its own cubemap gets the visible sky; read the cubemap
    if a level lights itself with a different one.
    """
    world = actor.get_world()
    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    selection = actors.get_selected_level_actors()
    capture = actors.spawn_actor_from_class(
        unreal.SceneCapture2D, comp.get_world_location(), unreal.Rotator(), transient=True)
    try:
        size = _SKY_CAPTURE_SIZE
        target = unreal.RenderingLibrary.create_render_target2d(
            world, size, size, unreal.TextureRenderTargetFormat.RTF_RGBA32F)
        cc = capture.capture_component2d
        for prop, value in (("texture_target", target), ("fov_angle", 90.0),
                            ("capture_every_frame", False), ("capture_on_movement", False),
                            ("capture_source", unreal.SceneCaptureSource.SCS_SCENE_COLOR_HDR),
                            ("override_custom_near_clipping_plane", True),
                            ("custom_near_clipping_plane", _f(ue2g_common.safe_get_prop(
                                comp, "sky_distance_threshold", 150000.0), 150000.0))):
            cc.set_editor_property(prop, value)

        sky, below = [], []
        for pitch, yaw in ((90, 0), (0, 0), (0, 90), (0, 180), (0, 270)):
            capture.set_actor_rotation(unreal.Rotator(roll=0, pitch=pitch, yaw=yaw), False)
            cc.capture_scene()
            pixels = unreal.RenderingLibrary.read_render_target_raw(world, target, False)
            for index, px in enumerate(pixels):
                row, col = divmod(index, size)
                x = (col + 0.5) / size * 2.0 - 1.0
                y = 1.0 - (row + 0.5) / size * 2.0
                inv = 1.0 / math.sqrt(1.0 + x * x + y * y)
                sine = (1.0 if pitch else y) * inv
                rgb = (px.r, px.g, px.b)
                if sine > 0.0:
                    # Solid angle times cosine: what the pixel adds to the ground's light.
                    sky.append((sine, inv ** 3 * sine, rgb))
                else:
                    below.append(rgb)
    finally:
        actors.destroy_actor(capture)
        actors.set_selected_level_actors(selection)

    if not any(sum(rgb) > 0.0 for _, _, rgb in sky):
        return None
    horizon, top, falloff = _fit_sky_gradient(sky)
    if _b(ue2g_common.safe_get_prop(comp, "lower_hemisphere_is_black", True), True):
        ground = ue2g_common.linear_color_to_list(
            ue2g_common.safe_get_prop(comp, "lower_hemisphere_color", None)
            or unreal.LinearColor(0.0, 0.0, 0.0))
    else:
        ground = ([sum(rgb[i] for rgb in below) / len(below) for i in range(3)]
                  if below else [0.0, 0.0, 0.0])
    return {"top": top, "horizon": horizon, "ground": ground, "falloff": falloff}


def _build_sky_light(actor):
    try:
        comp = actor.get_component_by_class(unreal.SkyLightComponent)
    except Exception as e:
        _log_actor_warning(actor, "failed to get SkyLightComponent", e)
        comp = None
    if comp is None:
        return None
    if (not _b(ue2g_common.safe_get_prop(comp, "visible", True), True)
            or _b(ue2g_common.safe_get_prop(comp, "hidden_in_game", False), False)
            or _actor_is_hidden(actor)
            or not _b(ue2g_common.safe_get_prop(comp, "affects_world", True), True)):
        return None

    intensity = ue2g_common.safe_get_prop(comp, "intensity", None)
    color_raw = ue2g_common.safe_get_prop(comp, "light_color", None)
    color = ue2g_common.linear_color_to_list(color_raw) if color_raw is not None else [1.0, 1.0, 1.0]

    gradient = None
    try:
        gradient = _capture_sky(actor, comp)
    except Exception as e:
        _log_actor_warning(actor, "could not capture the sky; Godot's default sky is used", e)

    return {
        "intensity": _f(intensity, 1.0),
        "color": color,
        "gradient": gradient,
    }


# ---------------------------------------------------------------------------
# Decals
# ---------------------------------------------------------------------------

# A 120 degree rotation about (1,1,1): local X -> Y -> Z -> X. See
# _decal_transform() for the derivation.
_DECAL_FIXUP_QUAT = (0.5, 0.5, 0.5, 0.5)


def _quat_multiply(q1, q2):
    """
    Hamilton product q1 * q2 for (x, y, z, w) tuples: rotates by q2 first,
    then by q1. Matches the matrix composition convention R(q1 * q2) =
    R(q1) . R(q2) used throughout ue2g_common.py's matrix_to_quat().
    """
    x1, y1, z1, w1 = q1
    x2, y2, z2, w2 = q2
    return (
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
    )


def _decal_transform(u_transform):
    """
    Returns the Godot transform dict for a decal's WORLD transform, with the
    UE -> Godot projection-axis fix-up folded into the rotation.

    Worked derivation:
      Let R_std = the standard converted rotation from
      ue2g_common.unreal_to_godot_transform, whose axis change sends
      (ux,uy,uz) to (uy,uz,-ux): UE local +X, +Y, +Z land on R_std's local
      -Z, +X, +Y.

      The decal's image axes are U = UE +Z and V = UE +Y, i.e. R_std's +Y and
      +X. A Godot Decal draws U along local +X and V along local +Z, so the
      fix-up R_fix in R_final = R_std . R_fix must satisfy
          R_fix . (1,0,0) = (0,1,0)   (U)
          R_fix . (0,0,1) = (1,0,0)   (V)
      which fixes the remaining column as R_fix . (0,1,0) = (0,0,1): UE -X.
      Godot projects along -Y, so along UE +X, the way the image reads upright.

      The scale must travel with the rotation. unreal_to_godot_transform
      returns it along R_std's axes, as [usy, usz, usx]. The correct world
      basis is R_std . S_std . R_fix and consumers build R_final . S, so
          S = R_fix^T . S_std . R_fix
      which permutes the entries to [usz, usx, usy]. Leaving it unpermuted
      swaps the decal's projection depth with its size on the wall.

    Takes the DecalComponent's WORLD transform, not the actor's: on a stock
    ADecalActor the component *is* the root and the two agree, but a Blueprint
    decal actor (or a decal component parented under a prop) carries a relative
    offset the actor transform knows nothing about.
    """
    std = ue2g_common.unreal_to_godot_transform(u_transform)
    q_std = tuple(std.get("rotation_quat", [0.0, 0.0, 0.0, 1.0]))
    q_final = _quat_multiply(q_std, _DECAL_FIXUP_QUAT)

    length = sum(c * c for c in q_final) ** 0.5
    if length > 0.0:
        q_final = tuple(c / length for c in q_final)
    else:
        q_final = (0.0, 0.0, 0.0, 1.0)

    scale = list(std.get("scale", [1.0, 1.0, 1.0]))
    if len(scale) >= 3:
        # R_fix^T . diag(sx, sy, sz) . R_fix  ==  diag(sy, sz, sx)
        std["scale"] = [scale[1], scale[2], scale[0]]

    std["rotation_quat"] = list(q_final)
    return std


# Godot's Decal.TEXTURE_ORM channel order. Matches _PACKED_LAYOUTS["orm"]/["arm"]
# in export_level_to_json; any other packing (RMA, MRA) cannot be bound to a Decal.
_GODOT_DECAL_ORM_CHANNELS = {"ao": 0, "roughness": 1, "metallic": 2}


# ---------------------------------------------------------------------------
# Decal atlas cropping (see docs/SCHEMA_V2.md "decals" -> uv_rect)
# ---------------------------------------------------------------------------
#
# Decal packs routinely ship ONE atlas texture and cut a different cell out of
# it per material, so a single T_Signs_BC.png serves four different signs. Unreal
# does that crop in the material graph. Godot's Decal has no UV transform of any
# kind, so unless the rect travels in the schema the importer binds the whole
# sheet and every decal renders as the entire atlas -- measured on
# SpaceshipInterior's M_Scifi_Signs_Decal_01..04, four TextureCoordinate nodes
# over one 1024x1024 sheet, where the "Exit sign" decal came into Godot showing
# all four signs at once.
#
# The form read here is the plain `TextureCoordinate` node: UV = uv * (U, V).
# With Unreal's default wrap addressing and |tiling| <= 1 that is a sub-rect, and
# the SIGN picks which end of the axis plus a mirror:
#     t > 0:  uv travels 0 -> t                  => rect [0, t],     upright
#     t < 0:  uv travels 0 -> -|t|, which wrap
#             sends to 1.0 -> 1-|t|              => rect [1-|t|, 1], MIRRORED
# |t| > 1 is genuine repetition, which a Godot Decal cannot express at all, so it
# is refused and logged rather than approximated into a wrong crop.
#
# The second form read here is the parameter-driven one, where the base material
# holds TextureCoordinate(1,1) -> Divide -> Add -> sampler and the cell is chosen
# per INSTANCE by scalar parameters (ModularSciFiStation's M_decal: "UV Divide",
# "U Tile", "V Tile"). UE 5.8 walks that wiring directly (see _uv_rect_from_graph,
# tried first); older engines cannot -- expression INPUTS are protected in Python --
# so they infer it here. What pinned the formula down was the VALUES: across all 16 MI_* instances UV Divide is 4.0 and U/V Tile take only
# {0, 0.25, 0.5, 0.75}, i.e. fractions rather than integer cell indices, which
# fits uv/divide + (u,v) and not (uv + (u,v))/divide. Rendering the 4x4 grid over
# T_numbers_01_basecolor confirmed it cell by cell -- MI_numbers_01_red lands on
# "1", MI_shape_u_white on the "U", MI_triangle_red on the triangle, all 16.
#
# Because that inference rests on names and graph SHAPE rather than on wiring, it
# is gated on both: the three parameters must all be present under known names AND
# the graph must carry Divide + Add + AppendVector with a TextureCoordinate left
# at (1,1). A material that misses any of those falls through uncropped.

# Tolerance for "is this tiling value 1.0" and friends. Tiling comes out of the
# engine as float32, so an exact == against 1.0 is not safe.
_UV_EPS = 1e-6

# The rect meaning "sample the whole texture", i.e. no crop to record.
_DECAL_UV_FULL_RECT = [0.0, 0.0, 1.0, 1.0]


def _tiling_to_span(value):
    """
    One axis of a TextureCoordinate tiling value as (offset, size, mirrored).

    Returns None when the value is not a crop at all: 0 (degenerate) or |t| > 1
    (real repetition, which a Godot Decal has no way to reproduce).
    """
    try:
        t = float(value)
    except (TypeError, ValueError):
        return None
    if t == 0.0 or abs(t) > 1.0 + _UV_EPS:
        return None
    size = min(abs(t), 1.0)
    if t > 0.0:
        return 0.0, size, False
    return 1.0 - size, size, True


def _base_material_of(material):
    """
    The base unreal.Material behind any MaterialInterface, or None.

    MaterialEditingLibrary.get_material_expressions only accepts a base Material,
    but a decal is just as likely to carry a MaterialInstance (or a chain of
    them), and the TextureCoordinate crop always lives in the base graph.
    """
    if material is None:
        return None
    getter = getattr(material, "get_base_material", None)
    if getter is not None:
        try:
            base = getter()
            if base is not None:
                return base
        except Exception:
            pass
    # Fall back to walking the parent chain; the bound is paranoia against a
    # cyclic .parent rather than a real depth limit (chains are 1-2 deep).
    node = material
    for _ in range(8):
        parent = ue2g_common.safe_get_prop(node, "parent", None)
        if parent is None:
            break
        node = parent
    return node


# Scalar parameter names understood as an atlas cell selector. Deliberately an
# EXACT-match whitelist after normalising case/spaces/underscores, like
# _DECAL_OPACITY_PARAM_NAMES: a substring test would read "UV Divide Strength" or
# a "Tile" tiling control as a cell index and crop every decal to a wrong corner.
_ATLAS_DIVIDE_PARAM_NAMES = frozenset((
    "uvdivide", "uvdivisions", "uvdiv", "atlasdivide", "atlasdivisions",
))
_ATLAS_U_PARAM_NAMES = frozenset(("utile", "uoffset", "atlasu", "ucell"))
_ATLAS_V_PARAM_NAMES = frozenset(("vtile", "voffset", "atlasv", "vcell"))

# The node set that makes a graph the "divide then offset" atlas shape.
_ATLAS_GRAPH_CLASSES = frozenset((
    "MaterialExpressionDivide", "MaterialExpressionAdd",
    "MaterialExpressionAppendVector",
))


def _normalise_param_name(name):
    return str(name or "").lower().replace(" ", "").replace("_", "")


def _decal_scalar_param(material, base, name):
    """A scalar parameter's value, taking a MaterialInstance's override if there
    is one and falling back to the base material's default. None when unreadable."""
    mel = getattr(unreal, "MaterialEditingLibrary", None)
    if mel is None:
        return None
    key = name
    name_type = getattr(unreal, "Name", None)
    if name_type is not None:
        try:
            key = name_type(name)
        except Exception:
            key = name

    instance_getter = getattr(mel, "get_material_instance_scalar_parameter_value", None)
    mi_type = getattr(unreal, "MaterialInstance", None)
    # Child to parent: the library getter refuses a MaterialInstanceDynamic, so its
    # overrides are read off the instance itself before asking about its parent.
    for _ in range(16):
        if mi_type is None or not isinstance(material, mi_type):
            break
        for override in ue2g_common.safe_get_prop(material, "scalar_parameter_values", None) or ():
            if str(override.parameter_info.name).lower() == str(name).lower():
                return float(override.parameter_value)
        if instance_getter is not None:
            try:
                value = instance_getter(material, key)
                if value is not None:
                    return float(value)
            except Exception:
                pass
        material = ue2g_common.safe_get_prop(material, "parent", None)

    default_getter = getattr(mel, "get_material_default_scalar_parameter_value", None)
    if default_getter is not None:
        try:
            value = default_getter(base, key)
            if value is not None:
                return float(value)
        except Exception:
            pass
    return None


def _uv_rect_from_atlas_params(material, base, expressions, actor=None):
    """
    The atlas cell chosen by "UV Divide"/"U Tile"/"V Tile" style scalars, as
    ([u0, v0, w, h], False, False), or None when this material is not that shape.

    Gated on graph shape as well as parameter names because the wiring itself is
    unreadable -- see the block comment above.
    """
    classes = set(type(ex).__name__ for ex in expressions)
    if not _ATLAS_GRAPH_CLASSES.issubset(classes):
        return None

    mel = getattr(unreal, "MaterialEditingLibrary", None)
    lister = getattr(mel, "get_scalar_parameter_names", None) if mel else None
    if lister is None:
        return None
    try:
        names = lister(base) or []
    except Exception:
        return None

    wanted = (("divide", _ATLAS_DIVIDE_PARAM_NAMES), ("u", _ATLAS_U_PARAM_NAMES),
              ("v", _ATLAS_V_PARAM_NAMES))
    found = {}
    for raw in names:
        key = _normalise_param_name(raw)
        for slot, allowed in wanted:
            if key in allowed and slot not in found:
                found[slot] = raw
    if len(found) != 3:
        return None

    values = {}
    for slot, raw in found.items():
        value = _decal_scalar_param(material, base, raw)
        if value is None:
            return None
        values[slot] = value

    divide, u0, v0 = values["divide"], values["u"], values["v"]
    if divide <= 0.0:
        return None
    size = 1.0 / divide
    if size >= 1.0 - _UV_EPS:
        # A 1x1 grid is the whole texture; nothing to crop.
        return None
    if not (-_UV_EPS <= u0 <= 1.0 and -_UV_EPS <= v0 <= 1.0):
        return None
    if u0 + size > 1.0 + _UV_EPS or v0 + size > 1.0 + _UV_EPS:
        # The cell would run off the edge and wrap, which is not a sub-rect.
        _log_actor_warning(
            actor, "decal atlas crop skipped",
            "'{}' selects a cell at ({}, {}) of size {} that runs past the "
            "texture edge".format(ue2g_common.safe_get_name(base), u0, v0, size))
        return None
    return [max(u0, 0.0), max(v0, 0.0), size, size], False, False


def _uv_affine(graph, node, material):
    """
    A UV expression as [(axis, scale, offset), ...] per component, each meaning
    scale * uv[axis] + offset (axis None for a constant). None when the graph does
    something a crop cannot express.
    """
    kind = ue2g_common.node_kind(node)
    prop = ue2g_common.safe_get_prop
    if kind == "TextureCoordinate":
        return [(0, _f(prop(node, "u_tiling", 1.0), 1.0), 0.0),
                (1, _f(prop(node, "v_tiling", 1.0), 1.0), 0.0)]
    if kind == "Constant":
        return [(None, 0.0, _f(prop(node, "r", 0.0), 0.0))]
    if kind == "Constant2Vector":
        return [(None, 0.0, _f(prop(node, c, 0.0), 0.0)) for c in ("r", "g")]
    if kind == "ScalarParameter":
        value = _decal_scalar_param(material, graph.base, str(prop(node, "parameter_name", "")))
        return None if value is None else [(None, 0.0, value)]

    children = {}
    for name, child, _out in graph.inputs(node):
        children[name] = _uv_affine(graph, child, material)
        if children[name] is None:
            return None
    if kind in ("Reroute", "ComponentMask"):
        if len(children) != 1:
            return None
        value = next(iter(children.values()))
        if kind == "Reroute":
            return value
        # A scalar reads the same from every channel.
        value = value * 4 if len(value) == 1 else value
        return [c for c, keep in zip(value, "rgba") if prop(node, keep, False)] or None
    if kind == "AppendVector":
        return children["A"] + children["B"] if len(children) == 2 else None
    if kind not in ("Add", "Subtract", "Multiply", "Divide"):
        return None

    # An unconnected pin reads the node's own constant.
    a = children.get("A") or [(None, 0.0, _f(prop(node, "const_a", 0.0), 0.0))]
    b = children.get("B") or [(None, 0.0, _f(prop(node, "const_b", 1.0), 1.0))]
    size = max(len(a), len(b))
    if any(len(v) not in (1, size) for v in (a, b)):
        return None
    result = []
    for (ax, a_scale, a_off), (bx, b_scale, b_off) in zip(
            a * size if len(a) == 1 else a, b * size if len(b) == 1 else b):
        if kind in ("Add", "Subtract"):
            if ax is not None and bx is not None and ax != bx:
                return None
            sign = 1.0 if kind == "Add" else -1.0
            result.append((ax if ax is not None else bx,
                           a_scale + sign * b_scale, a_off + sign * b_off))
            continue
        if kind == "Multiply" and ax is None:
            ax, a_scale, a_off, bx, b_scale, b_off = bx, b_scale, b_off, ax, a_scale, a_off
        if bx is not None or (kind == "Divide" and b_off == 0.0):
            return None
        factor = b_off if kind == "Multiply" else 1.0 / b_off
        result.append((ax, a_scale * factor, a_off * factor))
    return result


def _uv_rect_from_graph(material, actor=None):
    """
    The crop feeding the albedo sampler, read off the graph itself: the same
    ([u0, v0, w, h], flip_u, flip_v) as _decal_uv_rect, or None when the engine or
    the graph's shape cannot answer and the older readers should try.
    """
    trace = ue2g_common.trace_material_graph(material)
    sample = (trace or {"samples": {}})["samples"].get("albedo")
    base = _base_material_of(material)
    if sample is None or base is None:
        return None
    graph = ue2g_common.MaterialGraph(base)
    coords = [child for name, child, _out in graph.inputs(sample["node"])
              if name.lower() in ("uvs", "coordinates")]
    uv = _uv_affine(graph, coords[0], material) if coords else [(0, 1.0, 0.0), (1, 1.0, 0.0)]
    if uv is None or len(uv) != 2 or uv[0][0] != 0 or uv[1][0] != 1:
        return None

    rect, flips = [0.0, 0.0, 0.0, 0.0], [False, False]
    for axis, (_axis, scale, offset) in enumerate(uv):
        size = abs(scale)
        start = (offset if scale > 0.0 else offset + scale) % 1.0
        # A whole number of wraps lands on an edge, give or take float32 noise.
        if start > 1.0 - 1e-4 or start < 1e-4:
            start = 0.0
        if size < _UV_EPS or size > 1.0 + 1e-4:
            _log_actor_warning(
                actor, "decal atlas crop skipped",
                "'{}' tiles its texture {} times; a Godot Decal cannot repeat a "
                "texture inside its box".format(ue2g_common.safe_get_name(base), scale))
            return None, False, False
        # start + size may pass 1.0: the importer wraps, as Unreal's sampler does.
        rect[axis], rect[axis + 2] = start, min(size, 1.0)
        flips[axis] = scale < 0.0
    if rect[2] >= 1.0 - 1e-4 and rect[3] >= 1.0 - 1e-4 and not any(flips)             and not (rect[0] or rect[1]):
        return None, False, False
    return rect, flips[0], flips[1]


def _decal_uv_rect(material, actor=None):
    """
    The atlas sub-rect a decal material samples, as ([u0, v0, w, h], flip_u,
    flip_v), or (None, False, False) when it samples the texture whole or crops
    in a way that cannot be read.

    u0/v0/w/h are normalised 0..1 with v measured from the TOP of the image,
    which is where both Unreal's UV origin and Godot's Image row 0 already sit --
    no flip is needed to move between them.
    """
    base = _base_material_of(material)
    if base is None:
        return None, False, False

    found = _uv_rect_from_graph(material, actor)
    if found is not None:
        return found

    mel = getattr(unreal, "MaterialEditingLibrary", None)
    getter = getattr(mel, "get_material_expressions", None) if mel else None
    if getter is None:
        # Pre-5.x engines without the library: no supported way in, and the
        # `expressions` property has been protected since 5.7.
        return None, False, False

    try:
        expressions = getter(base) or []
    except Exception as e:
        _log_actor_warning(actor, "could not read decal material expressions", e)
        return None, False, False

    found = _uv_rect_from_texcoord(base, expressions, actor)
    if found is not None:
        return found
    found = _uv_rect_from_atlas_params(material, base, expressions, actor)
    if found is not None:
        return found
    return None, False, False


def _uv_rect_from_texcoord(base, expressions, actor=None):
    """
    The crop a bare TextureCoordinate node applies, as ([u0, v0, w, h], flip_u,
    flip_v), or None when there is none to read.
    """
    coords = [ex for ex in expressions if "TextureCoordinate" in type(ex).__name__]
    if not coords:
        return None
    if len(coords) > 1:
        # Which node feeds the albedo sampler is not something Python can see --
        # expression INPUTS are not exposed -- so with more than one the crop
        # would be a guess. The whole sheet is wrong but at least predictable.
        _log_actor_warning(
            actor, "decal atlas crop skipped",
            "'{}' has {} TextureCoordinate nodes; cannot tell which one feeds "
            "the albedo sampler".format(ue2g_common.safe_get_name(base), len(coords)))
        return None

    node = coords[0]
    raw_u = ue2g_common.safe_get_prop(node, "u_tiling", 1.0)
    raw_v = ue2g_common.safe_get_prop(node, "v_tiling", 1.0)
    u_span = _tiling_to_span(raw_u)
    v_span = _tiling_to_span(raw_v)
    if u_span is None or v_span is None:
        _log_actor_warning(
            actor, "decal atlas crop skipped",
            "'{}' repeats its texture (U={}, V={}); a Godot Decal cannot tile a "
            "texture inside its box".format(
                ue2g_common.safe_get_name(base), raw_u, raw_v))
        return None

    u0, width, flip_u = u_span
    v0, height, flip_v = v_span
    if (not flip_u and not flip_v
            and width >= 1.0 - _UV_EPS and height >= 1.0 - _UV_EPS):
        # Samples the whole sheet. This is also the M_decal case -- its
        # TextureCoordinate sits at (1,1) and the crop lives in the parameters --
        # so falling through here is what lets the parameter path run.
        return None
    return [u0, v0, width, height], flip_u, flip_v


# UE fades a decal out once its projected size drops below FadeScreenSize (a
# fraction of the view's half-height; default 0.01). Godot has no screen-size
# fade, only a distance one, so the exporter converts: an object of world radius
# r covers a screen fraction of r / (d * tan(fov/2)), which inverts to the
# distance at which UE would have dropped the decal. The FOV has to be assumed --
# Godot's Camera3D default (75 degrees vertical) is the only sane reference
# point, and the result is a soft fade rather than a hard cull, so being a few
# degrees off just moves the fade slightly.
_GODOT_DEFAULT_FOV_DEG = 75.0
_TAN_HALF_FOV = math.tan(math.radians(_GODOT_DEFAULT_FOV_DEG * 0.5))

# A tiny FadeScreenSize inverts to an absurd distance ("never fades"). Past this
# the fade is emitted as null rather than writing 10^6 into every scene.
_MAX_FADE_DISTANCE_M = 100000.0

# Scalar parameter names taken to mean "the decal's overall opacity", folded into
# Godot's Decal.modulate alpha. Deliberately an EXACT-match whitelist rather than
# a substring test like classify_scalar_parameter uses: a false positive here
# makes a decal transparent, and names such as "Opacity Mask Contrast" or
# "Alpha Threshold" are contrast controls, not opacity.
_DECAL_OPACITY_PARAM_NAMES = frozenset((
    "opacity", "decalopacity", "globalopacity", "overallopacity",
    "opacityscale", "opacitymultiplier", "opacitystrength", "opacityamount",
    "alpha", "decalalpha",
))


def _is_opacity_param(name):
    lowered = str(name or "").lower().replace(" ", "").replace("_", "")
    return lowered in _DECAL_OPACITY_PARAM_NAMES


def _decal_opacity(material):
    """
    Returns an explicit overall-opacity scalar from a decal material, or None.

    Godot's Decal has no opacity property of its own, but modulate's alpha
    multiplies the whole projection, so an `Opacity` parameter -- the standard
    way decal material instances are dialled back in UE -- can be carried
    across. Walks the instance chain child-first, matching
    extract_material_parameters' "first explicit value wins" rule.
    """
    visited = set()

    def _scan(mat):
        if mat is None or mat in visited:
            return None
        visited.add(mat)

        is_instance = isinstance(mat, unreal.MaterialInstance)
        if not is_instance and hasattr(unreal, "MaterialInstanceConstant"):
            is_instance = isinstance(mat, unreal.MaterialInstanceConstant)

        if is_instance:
            try:
                for s in (mat.get_editor_property("scalar_parameter_values") or []):
                    if _is_opacity_param(s.parameter_info.name):
                        return float(s.parameter_value)
            except Exception:
                pass
            return _scan(ue2g_common.safe_get_prop(mat, "parent", None))

        for pname, value in ue2g_common.iter_base_material_scalars(mat):
            if _is_opacity_param(pname):
                try:
                    return float(value)
                except Exception:
                    return None
        return None

    try:
        return _scan(material)
    except Exception:
        return None


def _decal_modulate(comp, params, material):
    """
    Godot Decal.modulate [r, g, b, a]: the component's DecalColor times the
    material's albedo tint, with any opacity parameter folded into alpha.

    Without this a decal whose colour lives in a parameter rather than in its
    albedo texture -- the usual setup for tinted blood/rust/paint instances --
    imported at full white. Two caveats worth knowing:
      * UE's DecalColor only reaches the shader when the material samples the
        Decal Color node. It defaults to white, so it only ever moves the
        result when someone deliberately set it, and honouring an explicitly
        authored colour beats dropping it.
      * The tint can legitimately exceed 1.0 (packs author dark albedo and
        scale it up), so only the negative side is clamped.
    """
    modulate = [1.0, 1.0, 1.0, 1.0]

    decal_color = ue2g_common.safe_get_prop(comp, "decal_color", None)
    if decal_color is not None:
        dc = ue2g_common.linear_color_to_list(decal_color, include_alpha=True)
        for i in range(min(4, len(dc))):
            modulate[i] = _f(dc[i], 1.0)

    tint = (params or {}).get("albedo_color")
    if isinstance(tint, (list, tuple)):
        for i in range(min(4, len(tint))):
            modulate[i] *= _f(tint[i], 1.0)

    opacity = _decal_opacity(material)
    if opacity is not None:
        modulate[3] *= min(max(opacity, 0.0), 1.0)

    return [max(0.0, c) for c in modulate]


def _decal_color_grade(material):
    """
    (brightness, hue shift) the graph applies between a decal's albedo sample and
    its base color. (1.0, 0.0) when it applies none or the engine cannot say.

    Wall-paint packs grade one shared atlas per decal this way. Vector tints are
    not read here: extract_material_parameters already has them.
    """
    base = _base_material_of(material)
    mel = getattr(unreal, "MaterialEditingLibrary", None)
    prop = getattr(getattr(unreal, "MaterialProperty", None), "MP_BASE_COLOR", None)
    if base is None or prop is None or not hasattr(mel, "get_inputs_for_material_expression"):
        return 1.0, 0.0
    graph = ue2g_common.MaterialGraph(base)
    kind = ue2g_common.node_kind

    def has_sample(node, depth=0):
        if kind(node).startswith("TextureSample"):
            return True
        return depth < 12 and any(has_sample(c, depth + 1) for _n, c, _o in graph.inputs(node))

    def scalar(node):
        if kind(node) == "Constant":
            return _f(ue2g_common.safe_get_prop(node, "r", 1.0), 1.0)
        if kind(node) == "ScalarParameter":
            return _decal_scalar_param(
                material, base, str(ue2g_common.safe_get_prop(node, "parameter_name", "")))
        return None

    brightness, hue = 1.0, 0.0
    node = mel.get_material_property_input_node(base, prop)
    for _step in range(12):
        if node is None or kind(node).startswith("TextureSample"):
            break
        inputs = list(graph.inputs(node))
        color = [c for _n, c, _o in inputs if has_sample(c)]
        rest = [c for _n, c, _o in inputs if not has_sample(c)]
        if len(color) != 1:
            break
        value = scalar(rest[0]) if len(rest) == 1 else None
        if kind(node) == "Multiply":
            if not rest:
                value = _f(ue2g_common.safe_get_prop(
                    node, "const_b" if inputs[0][0] == "A" else "const_a", 1.0), 1.0)
            if value is not None:
                brightness *= max(value, 0.0)
        elif kind(node) == "MaterialFunctionCall":
            function = ue2g_common.safe_get_prop(node, "material_function", None)
            if ue2g_common.safe_get_name(function) != "HueShift":
                break
            hue += value or 0.0
        elif kind(node) not in ("Clamp", "Saturate", "Desaturation", "Reroute"):
            break
        node = color[0]
    return brightness, hue % 1.0


def _bake_decal_scale(size_m, godot_transform):
    """
    Moves a decal's scale into its size, leaving only the sign behind (a mirror).

    Same box, but Godot's Forward+ clustering culls a scaled Decal as if it were
    smaller, cutting it off along 32 px blocks: 20 of Downtown_Alley's 30 rendered
    crops lost part of their picture on Godot 4.7.2 before this.
    """
    scale = godot_transform.get("scale") or [1.0, 1.0, 1.0]
    godot_transform["scale"] = [-1.0 if s < 0.0 else 1.0 for s in scale]
    return [abs(v * s) for v, s in zip(size_m, scale)]


def _decal_distance_fade(comp, size_m, scale):
    """
    Converts UE's FadeScreenSize into Godot (distance_fade_begin,
    distance_fade_length) in metres, or (None, None) when UE asked for no fade.

    `size_m` is the decal's local box and `scale` its converted local scale, so
    the lateral (width/height) world extent is size_m[0]*scale[0] and
    size_m[2]*scale[2] -- the projection depth (index 1) is not what determines
    on-screen size. The decal is fully gone at the distance UE would have
    dropped it, fading in over the last quarter of the way there.
    """
    fade_screen_size = _f(ue2g_common.safe_get_prop(comp, "fade_screen_size", 0.0), 0.0)
    if fade_screen_size <= 0.0:
        return None, None

    def _axis_scale(index):
        try:
            return abs(_f(scale[index], 1.0)) or 1.0
        except Exception:
            return 1.0

    radius = 0.5 * max(abs(_f(size_m[0], 1.0)) * _axis_scale(0),
                       abs(_f(size_m[2], 1.0)) * _axis_scale(2))
    if radius <= 0.0:
        return None, None

    cull_m = radius / (fade_screen_size * _TAN_HALF_FOV)
    if cull_m > _MAX_FADE_DISTANCE_M:
        return None, None

    length = max(1.0, cull_m * 0.25)
    return max(0.0, cull_m - length), length


def _decal_components(actor):
    """Every DecalComponent on an actor, in declaration order; never raises."""
    try:
        comps = actor.get_components_by_class(unreal.DecalComponent)
    except Exception as e:
        _log_actor_warning(actor, "failed to list DecalComponents", e)
        return []
    return [c for c in (comps or []) if c is not None]


def _build_decal_entries(actor, collected_textures):
    """
    One schema entry per DecalComponent on `actor`.

    Scanning components rather than keying off unreal.DecalActor is what lets a
    Blueprint prop with a decal component -- a scorched wall panel, a signed
    crate -- export at all; those used to vanish silently. Actors carrying more
    than one decal get the component name appended so the Godot node names stay
    unique and traceable.
    """
    comps = _decal_components(actor)
    label = _safe_label(actor)
    entries = []
    for comp in comps:
        name = label
        if len(comps) > 1:
            name = "{}_{}".format(label, ue2g_common.safe_get_name(comp))
        # Guarded per component: this runs before the light/volume dispatch in
        # collect_environment, so an unreadable decal must not cost the actor
        # its light export too.
        try:
            entry = _build_decal_entry(actor, comp, name, collected_textures)
        except Exception as e:
            _log_actor_warning(actor, "failed to build decal entry", e)
            continue
        if entry is not None:
            entries.append(entry)
    return entries


def _build_decal_entry(actor, comp, name, collected_textures):
    if comp is None:
        return None
    if _b(ue2g_common.safe_get_prop(comp, "is_editor_only", False), False):
        return None

    decal_size = ue2g_common.safe_get_prop(comp, "decal_size", None)
    if decal_size is not None:
        # UE decal_size is HALF-size cm as (X=projection depth, Y=image height, Z=image
        # width). Godot Decal.size is FULL-size meters as (width, projection depth, height).
        size_m = [
            _f(decal_size.z) * 2.0 * ue2g_common.CM_TO_M,
            _f(decal_size.x) * 2.0 * ue2g_common.CM_TO_M,
            _f(decal_size.y) * 2.0 * ue2g_common.CM_TO_M,
        ]
    else:
        size_m = [1.0, 1.0, 1.0]

    sort_order = int(_f(ue2g_common.safe_get_prop(comp, "sort_order", 0), 0))

    material = ue2g_common.safe_get_prop(comp, "decal_material", None)
    material_name = "None"
    material_path = "None"
    textures = {"albedo": None, "normal": None, "orm": None, "emission": None,
                "texture_paths": {}}
    params = None

    if material is not None:
        try:
            material_name = material.get_name()
            material_path = material.get_path_name()
        except Exception as e:
            _log_actor_warning(actor, "could not read decal material identity", e)

        try:
            params = extract_material_parameters(material, collected_textures)
            if params:
                paths = params.get("texture_paths") or {}
                textures["albedo"] = params.get("albedo_texture")
                textures["normal"] = params.get("normal_texture")
                textures["emission"] = params.get("emissive_texture")
                for key, slot in (("albedo", "albedo_texture"),
                                  ("normal", "normal_texture"),
                                  ("emission", "emissive_texture")):
                    if paths.get(slot):
                        textures["texture_paths"][key] = paths[slot]

                # Godot's Decal.TEXTURE_ORM slot is hard-wired to R=AO,
                # G=roughness, B=metallic and exposes no per-channel selectors
                # (unlike BaseMaterial3D), so ONLY a map already in that order
                # can be bound. A standalone greyscale roughness map has the
                # roughness value in all three channels, which would read back
                # as AO=roughness (backwards -- rougher gets less occlusion) and
                # metallic=roughness (a 0.9-rough concrete decal renders as
                # chrome). Binding nothing is strictly better than that.
                packed = params.get("packed_texture")
                if packed and params.get("packed_channels") == _GODOT_DECAL_ORM_CHANNELS:
                    textures["orm"] = packed
                    if paths.get("packed_texture"):
                        textures["texture_paths"]["orm"] = paths["packed_texture"]
                elif packed:
                    _log_actor_warning(
                        actor, "decal ORM map skipped",
                        "'{}' is packed as {} but Godot decals require ORM order "
                        "(R=AO, G=roughness, B=metallic)".format(
                            packed, params.get("packed_channels")))
        except Exception as e:
            _log_actor_warning(actor, "failed to extract decal material parameters", e)

        # The atlas crop, when the material has one. Emitted only when it is a
        # real crop, so an ordinary one-texture-per-decal material's entry is
        # byte-for-byte what it was before this existed.
        try:
            uv_rect, flip_u, flip_v = _decal_uv_rect(material, actor)
            if uv_rect is not None:
                textures["uv_rect"] = uv_rect
                textures["flip_u"] = flip_u
                textures["flip_v"] = flip_v
        except Exception as e:
            _log_actor_warning(actor, "failed to read decal atlas crop", e)
        try:
            brightness, hue = _decal_color_grade(material)
            if abs(brightness - 1.0) > 1e-3:
                textures["brightness"] = brightness
            if 1e-3 < hue < 1.0 - 1e-3:
                textures["hue_shift"] = hue
        except Exception as e:
            _log_actor_warning(actor, "failed to read decal color grade", e)

    godot_transform = _decal_transform(_component_world_transform(actor, comp))
    fade_begin, fade_length = _decal_distance_fade(
        comp, size_m, godot_transform.get("scale") or [1.0, 1.0, 1.0])
    size_m = _bake_decal_scale(size_m, godot_transform)

    # A decal component (or its owning actor) hidden in game is content the
    # level explicitly turned off; a Godot node that ignores that arrives visible.
    visible = (_b(ue2g_common.safe_get_prop(comp, "visible", True), True)
               and not _b(ue2g_common.safe_get_prop(comp, "hidden_in_game", False), False)
               and not _actor_is_hidden(actor))

    return {
        "name": name,
        "godot_transform": godot_transform,
        "size_m": size_m,
        "sort_order": sort_order,
        "visible": visible,
        "modulate": _decal_modulate(comp, params, material),
        "fade_screen_size": _f(ue2g_common.safe_get_prop(comp, "fade_screen_size", 0.0), 0.0),
        "distance_fade_begin_m": fade_begin,
        "distance_fade_length_m": fade_length,
        "material_name": material_name,
        "material_path": material_path,
        "textures": textures,
    }


def _component_world_transform(actor, comp):
    """
    A scene component's world transform, falling back to the actor's.

    The actor transform is only the same thing when the component *is* the
    root -- true for a plain DecalActor or PointLight, false for every decal
    or light hanging off a Blueprint, which is exactly the content that
    component-level collection exists to pick up.
    """
    try:
        transform = comp.get_world_transform()
        if transform is not None:
            return transform
    except Exception as e:
        _log_actor_warning(actor, "could not read component world transform", e)
    return actor.get_actor_transform()


# ---------------------------------------------------------------------------
# Reflection Captures (BoxReflectionCapture / SphereReflectionCapture)
# ---------------------------------------------------------------------------

def _build_reflection_probe_entries(actor):
    """Collects BoxReflectionCaptureComponent and SphereReflectionCaptureComponent
    from an actor (including Blueprint props)."""
    entries = []
    box_cls = getattr(unreal, "BoxReflectionCaptureComponent", None)
    sph_cls = getattr(unreal, "SphereReflectionCaptureComponent", None)
    comps = []
    for cls, shape in ((box_cls, "box"), (sph_cls, "sphere")):
        if cls is None:
            continue
        try:
            for c in (actor.get_components_by_class(cls) or []):
                comps.append((c, shape))
        except Exception:
            continue

    label = _safe_label(actor)
    for comp, shape in comps:
        if comp is None or _b(ue2g_common.safe_get_prop(comp, "is_editor_only", False), False):
            continue
        name = label if len(comps) == 1 else "{}_{}".format(label, ue2g_common.safe_get_name(comp))
        try:
            godot_transform = ue2g_common.unreal_to_godot_transform(_component_world_transform(actor, comp))
            sc = godot_transform.get("scale") or [1.0, 1.0, 1.0]
            if shape == "box":
                # UE BoxTransitionDistance (cm) + component scale, or box_extent if exposed.
                # Godot ReflectionProbe does not support non-unit node scale cleanly, so fold scale into size_m.
                box_ext = ue2g_common.safe_get_prop(comp, "box_extent", None)
                if box_ext is not None:
                    size_m = [
                        max(0.1, abs(_f(box_ext.y, 100.0)) * 2.0 * ue2g_common.CM_TO_M * abs(_f(sc[0], 1.0))),
                        max(0.1, abs(_f(box_ext.z, 100.0)) * 2.0 * ue2g_common.CM_TO_M * abs(_f(sc[1], 1.0))),
                        max(0.1, abs(_f(box_ext.x, 100.0)) * 2.0 * ue2g_common.CM_TO_M * abs(_f(sc[2], 1.0))),
                    ]
                else:
                    # UE's UBoxReflectionCaptureComponent has no extent of its own: its world
                    # scale IS the half-extent in cm (1000, 1000, 400 on a fresh actor).
                    size_m = [max(0.1, abs(_f(sc[i], 1.0)) * 2.0 * ue2g_common.CM_TO_M) for i in range(3)]
                godot_transform["scale"] = [1.0, 1.0, 1.0]
                blend_m = max(0.0, _f(ue2g_common.safe_get_prop(comp, "box_transition_distance", 100.0), 100.0) * ue2g_common.CM_TO_M)
                box_proj = True
            else:
                radius_cm = _f(ue2g_common.safe_get_prop(comp, "influence_radius", 3000.0), 3000.0)
                max_sc = max(abs(_f(sc[0], 1.0)), abs(_f(sc[1], 1.0)), abs(_f(sc[2], 1.0)))
                diam_m = max(0.2, abs(radius_cm) * 2.0 * ue2g_common.CM_TO_M * max_sc)
                size_m = [diam_m, diam_m, diam_m]
                godot_transform["scale"] = [1.0, 1.0, 1.0]
                blend_m = 0.0
                box_proj = False

            brightness = max(0.0, _f(ue2g_common.safe_get_prop(comp, "brightness", 1.0), 1.0))
            visible = (_b(ue2g_common.safe_get_prop(comp, "visible", True), True)
                       and not _b(ue2g_common.safe_get_prop(comp, "hidden_in_game", False), False)
                       and not _actor_is_hidden(actor))
            entries.append({
                "name": name,
                "shape": shape,
                "godot_transform": godot_transform,
                "size_m": size_m,
                "intensity": brightness,
                "box_projection": box_proj,
                "blend_distance_m": blend_m,
                "visible": visible,
            })
        except Exception as e:
            _log_actor_warning(actor, "failed to build reflection probe entry", e)
    return entries


# ---------------------------------------------------------------------------
# Cameras (CameraComponent / CineCameraComponent)
# ---------------------------------------------------------------------------

def _build_camera_entries(actor):
    """Collects CameraComponent (including CineCameraComponent) from an actor."""
    cam_cls = getattr(unreal, "CameraComponent", None)
    if cam_cls is None:
        return []
    try:
        comps = list(actor.get_components_by_class(cam_cls) or [])
    except Exception:
        return []
    label = _safe_label(actor)
    entries = []
    for comp in comps:
        if comp is None or _b(ue2g_common.safe_get_prop(comp, "is_editor_only", False), False):
            continue
        name = label if len(comps) == 1 else "{}_{}".format(label, ue2g_common.safe_get_name(comp))
        try:
            proj_raw = ue2g_common.safe_get_prop(comp, "projection_mode", None)
            proj_str = str(getattr(proj_raw, "name", proj_raw) or "PERSPECTIVE").upper()
            projection = "orthogonal" if ("ORTHO" in proj_str or proj_str == "1") else "perspective"
            # CineCameraComponent derives horizontal FOV from focal length + filmback;
            # prefer current_horizontal_fov when present and positive.
            cine_fov = _f(ue2g_common.safe_get_prop(comp, "current_horizontal_fov", 0.0), 0.0)
            raw_fov = cine_fov if cine_fov > 0.0 else _f(ue2g_common.safe_get_prop(comp, "field_of_view", 90.0), 90.0)
            fov_deg = max(1.0, min(179.0, raw_fov))
            ortho_width_m = max(0.05, _f(ue2g_common.safe_get_prop(comp, "ortho_width", 512.0), 512.0) * ue2g_common.CM_TO_M)
            # In Unreal, ortho_near_clip_plane / ortho_far_clip_plane (default -768 / 2097152 cm)
            # only govern Orthographic mode; perspective cameras use an infinite reverse-Z frustum,
            # so use Godot's clean 0.05..4000 m defaults for perspective cameras.
            if projection == "orthogonal":
                near_cm = _f(ue2g_common.safe_get_prop(comp, "ortho_near_clip_plane", 10.0), 10.0)
                far_cm = _f(ue2g_common.safe_get_prop(comp, "ortho_far_clip_plane", 100000.0), 100000.0)
                near_m = max(0.01, near_cm * ue2g_common.CM_TO_M) if near_cm > 0.0 else 0.05
                far_m = max(1.0, far_cm * ue2g_common.CM_TO_M) if far_cm > 0.0 else 4000.0
            else:
                near_m = 0.05
                far_m = 4000.0
            aspect = max(0.1, _f(ue2g_common.safe_get_prop(comp, "aspect_ratio", 1.777778), 1.777778))
            entries.append({
                "name": name,
                "godot_transform": ue2g_common.unreal_to_godot_transform(_component_world_transform(actor, comp)),
                "projection": projection,
                "fov_deg": fov_deg,
                "ortho_width_m": ortho_width_m,
                "near_clip_m": near_m,
                "far_clip_m": far_m,
                "aspect_ratio": aspect,
            })
        except Exception as e:
            _log_actor_warning(actor, "failed to build camera entry", e)
    return entries


# ---------------------------------------------------------------------------
# Spatial Audio (AudioComponent / AmbientSound)
# ---------------------------------------------------------------------------

def _volume_linear_to_db(mult):
    m = max(0.0, _f(mult, 1.0))
    if m <= 1e-5:
        return -80.0
    return round(20.0 * math.log10(m), 3)


def _build_audio_entries(actor, collected_sounds=None, sound_refs=None):
    """Collects AudioComponent (AmbientSound actors + Blueprint audio components)."""
    aud_cls = getattr(unreal, "AudioComponent", None)
    if aud_cls is None:
        return []
    try:
        comps = list(actor.get_components_by_class(aud_cls) or [])
    except Exception:
        return []
    label = _safe_label(actor)
    entries = []
    sound_wave_cls = getattr(unreal, "SoundWave", None)
    for comp in comps:
        if comp is None or _b(ue2g_common.safe_get_prop(comp, "is_editor_only", False), False):
            continue
        name = label if len(comps) == 1 else "{}_{}".format(label, ue2g_common.safe_get_name(comp))
        try:
            sound = ue2g_common.safe_get_prop(comp, "sound", None)
            sound_name = None
            sound_file = None
            looping = False
            sound_wave_obj = None
            if sound is not None:
                sound_name = ue2g_common.sanitize_name(ue2g_common.safe_get_name(sound))
                if sound_wave_cls is not None and isinstance(sound, sound_wave_cls):
                    sound_wave_obj = sound
                    sound_file = "%s.wav" % sound_name
                    looping = _b(ue2g_common.safe_get_prop(sound, "looping", False), False)
                    if collected_sounds is not None:
                        collected_sounds.add(sound)

            vol_mult = _f(ue2g_common.safe_get_prop(comp, "volume_multiplier", 1.0), 1.0)
            pitch = max(0.01, _f(ue2g_common.safe_get_prop(comp, "pitch_multiplier", 1.0), 1.0))
            auto_play = _b(ue2g_common.safe_get_prop(comp, "auto_activate", True), True)
            is_spatial = _b(ue2g_common.safe_get_prop(comp, "allow_spatialization", True), True)

            att_radius_m = 40.0
            # In Unreal, attenuation_overrides is a value struct (never None), so
            # override_attenuation (bOverrideAttenuation) decides whether it takes
            # precedence over the component/SoundWave SoundAttenuation asset.
            override_att = _b(ue2g_common.safe_get_prop(comp, "override_attenuation", False), False)
            att_settings = None
            if override_att:
                att_settings = ue2g_common.safe_get_prop(comp, "attenuation_overrides", None)
            if att_settings is None:
                att_asset = ue2g_common.safe_get_prop(comp, "attenuation_settings", None)
                if att_asset is None and sound is not None:
                    att_asset = ue2g_common.safe_get_prop(sound, "attenuation_settings", None)
                if att_asset is not None:
                    att_settings = ue2g_common.safe_get_prop(att_asset, "attenuation", None)
            if att_settings is None:
                att_settings = ue2g_common.safe_get_prop(comp, "attenuation_overrides", None)
            if att_settings is not None:
                falloff = _f(ue2g_common.safe_get_prop(att_settings, "falloff_distance", 3600.0), 3600.0)
                ext = ue2g_common.safe_get_prop(att_settings, "attenuation_shape_extents", None)
                inner = _f(ext.x, 400.0) if ext is not None else 400.0
                att_radius_m = max(0.1, (inner + falloff) * ue2g_common.CM_TO_M)
                if not _b(ue2g_common.safe_get_prop(att_settings, "spatialize", True), True):
                    is_spatial = False

            entry = {
                "name": name,
                "godot_transform": ue2g_common.unreal_to_godot_transform(_component_world_transform(actor, comp)),
                "sound_name": sound_name,
                "sound_file": sound_file,
                "volume_db": _volume_linear_to_db(vol_mult),
                "pitch_scale": pitch,
                "attenuation_radius_m": round(att_radius_m, 3),
                "is_spatialized": is_spatial,
                "auto_play": auto_play,
                "looping": looping,
            }
            entries.append(entry)
            if sound_refs is not None and sound_wave_obj is not None:
                sound_refs.append((entry, sound_wave_obj))
        except Exception as e:
            _log_actor_warning(actor, "failed to build audio entry", e)
    return entries


def export_sound_waves(sounds, audio_dir, name_map=None):
    """Exports collected Unreal SoundWave assets to <audio_dir>/<name>.wav."""
    if not sounds:
        return {"exported": [], "failed": []}
    os.makedirs(audio_dir, exist_ok=True)
    if name_map is None:
        name_map = ue2g_common.build_export_name_map(sounds, kind="audio")
    tasks = []
    seen = set()
    for snd in sounds:
        if snd is None or snd in seen:
            continue
        seen.add(snd)
        name = name_map.get(snd) or ue2g_common.sanitize_name(ue2g_common.safe_get_name(snd))
        filename = os.path.join(audio_dir, "%s.wav" % name)
        task = unreal.AssetExportTask()
        task.object = snd
        task.filename = filename
        task.automated = True
        task.prompt = False
        task.replace_identical = True
        tasks.append((name, filename, task))
    result = {"exported": [], "failed": []}
    if tasks:
        unreal.Exporter.run_asset_export_tasks([t[2] for t in tasks])
        for name, filename, _t in tasks:
            if os.path.isfile(filename):
                result["exported"].append(name)
            else:
                result["failed"].append(name)
    return result


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def collect_environment(all_actors, collected_textures,
                        include_lights=True, include_decals=True,
                        include_reflection_probes=True,
                        include_cameras=True,
                        include_audio=True,
                        collected_sounds=None):
    """
    Scans all_actors and returns:
        {"lights": [...], "post_process": [...], "height_fog": {...} | None,
         "sky_light": {...} | None, "has_sky_atmosphere": bool,
         "gi_method": str | None, "decals": [...],
         "reflection_probes": [...], "cameras": [...], "audio": [...]}

    Never raises and never shows dialogs: failures are logged via
    unreal.log_warning and the affected actor/feature is simply skipped.
    """
    result = {
        "lights": [],
        "post_process": [],
        "height_fog": None,
        "sky_light": None,
        "has_sky_atmosphere": False,
        "gi_method": _project_gi_method() if include_lights else None,
        "decals": [],
        "reflection_probes": [],
        "cameras": [],
        "audio": [],
    }

    try:
        if collected_textures is None:
            collected_textures = set()
        audio_sound_refs = []

        for actor in (all_actors or []):
            try:
                if actor is None:
                    continue

                # Component-level scans run BEFORE any actor-class branch that
                # continues, so Blueprint props carrying decals, lights, probes,
                # cameras, or audio components are never dropped.
                if include_decals:
                    result["decals"].extend(_build_decal_entries(actor, collected_textures))
                if include_reflection_probes:
                    result["reflection_probes"].extend(_build_reflection_probe_entries(actor))
                if include_cameras:
                    result["cameras"].extend(_build_camera_entries(actor))
                if include_audio:
                    result["audio"].extend(_build_audio_entries(actor, collected_sounds, audio_sound_refs))
                if not include_lights:
                    continue
                result["lights"].extend(_build_light_entries(actor))

                if isinstance(actor, unreal.PostProcessVolume):
                    entry = _build_post_process_entry(actor)
                    if entry is not None:
                        result["post_process"].append(entry)
                    continue

                if isinstance(actor, unreal.ExponentialHeightFog):
                    fog = _build_height_fog(actor)
                    if fog is not None:
                        result["height_fog"] = fog
                    continue

                if isinstance(actor, unreal.SkyLight):
                    sky = _build_sky_light(actor)
                    if sky is not None:
                        result["sky_light"] = sky
                    continue

                if _SKY_ATMOSPHERE_CLASS is not None and isinstance(actor, _SKY_ATMOSPHERE_CLASS):
                    if not _actor_is_hidden(actor):
                        sky_comp = None
                        sky_comp_cls = getattr(unreal, "SkyAtmosphereComponent", None)
                        if sky_comp_cls is not None and hasattr(actor, "get_component_by_class"):
                            try:
                                sky_comp = actor.get_component_by_class(sky_comp_cls)
                            except Exception:
                                sky_comp = None
                        if sky_comp is None or (
                                _b(ue2g_common.safe_get_prop(sky_comp, "visible", True), True)
                                and not _b(ue2g_common.safe_get_prop(sky_comp, "hidden_in_game", False), False)):
                            result["has_sky_atmosphere"] = True
                    continue

            except Exception as actor_err:
                _log_actor_warning(actor, "failed to process actor", actor_err)

        # Disambiguate colliding SoundWave export filenames to match export_sound_waves.
        if audio_sound_refs:
            all_sounds = set(collected_sounds or ())
            for _entry, snd in audio_sound_refs:
                all_sounds.add(snd)
            sound_name_map = ue2g_common.build_export_name_map(all_sounds, kind="audio")
            for entry, snd in audio_sound_refs:
                final_name = sound_name_map.get(snd)
                if final_name:
                    entry["sound_file"] = "%s.wav" % final_name

    except Exception as outer_err:
        unreal.log_warning(
            "export_environment: collect_environment failed entirely: {}".format(outer_err)
        )

    return result
